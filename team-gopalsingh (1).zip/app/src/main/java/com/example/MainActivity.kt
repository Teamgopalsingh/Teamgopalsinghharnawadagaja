package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.MainViewModel
import com.example.ui.NavigationScreen
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppRoyalHeader
import com.example.ui.screens.*
import com.example.ui.theme.TeamGopalSinghTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            TeamGopalSinghTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route ?: NavigationScreen.Splash.route

                val villages by viewModel.villages.collectAsState()
                val developmentProjects by viewModel.developmentProjects.collectAsState()
                val schools by viewModel.schools.collectAsState()
                val healthCentres by viewModel.healthCentres.collectAsState()
                val govtSchemes by viewModel.govtSchemes.collectAsState()
                val publicContacts by viewModel.publicContacts.collectAsState()
                val newsArticles by viewModel.newsArticles.collectAsState()
                val teamMembers by viewModel.teamMembers.collectAsState()
                val socialPosts by viewModel.socialPosts.collectAsState()
                val complaints by viewModel.complaints.collectAsState()
                val auditLogs by viewModel.auditLogs.collectAsState()
                val legalInfos by viewModel.legalInfos.collectAsState()
                val socialLinks by viewModel.socialLinks.collectAsState()
                val promises by viewModel.promises.collectAsState()
                val promiseSubmissions by viewModel.promiseSubmissions.collectAsState()
                val chatMessages by viewModel.chatMessages.collectAsState()

                val isAiThinking by viewModel.isAiThinking.collectAsState()
                val adminRole by viewModel.adminRole.collectAsState()
                val savedItemIds by viewModel.savedItemIds.collectAsState()
                val userName by viewModel.userName.collectAsState()
                val userMobile by viewModel.userMobile.collectAsState()
                val userVillage by viewModel.userVillage.collectAsState()

                val hideTopAndBottom = currentRoute == NavigationScreen.Splash.route ||
                        currentRoute == NavigationScreen.Onboarding.route

                Scaffold(
                    topBar = {
                        if (!hideTopAndBottom) {
                            AppRoyalHeader(
                                currentScreenTitle = "टीम गोपालसिंह",
                                onAdminClick = { navController.navigate(NavigationScreen.AdminDashboard.route) },
                                onSearchClick = { navController.navigate(NavigationScreen.GlobalSearch.route) },
                                onNotificationClick = { navController.navigate(NavigationScreen.News.route) }
                            )
                        }
                    },
                    bottomBar = {
                        if (!hideTopAndBottom) {
                            AppBottomBar(
                                currentRoute = currentRoute,
                                onNavigate = { screen ->
                                    navController.navigate(screen.route) {
                                        popUpTo(NavigationScreen.Home.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        NavHost(
                            navController = navController,
                            startDestination = NavigationScreen.Splash.route
                        ) {
                            composable(NavigationScreen.Splash.route) {
                                SplashScreen(
                                    onTimeout = {
                                        navController.navigate(NavigationScreen.Onboarding.route) {
                                            popUpTo(NavigationScreen.Splash.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(NavigationScreen.Onboarding.route) {
                                OnboardingScreen(
                                    onStartClick = {
                                        navController.navigate(NavigationScreen.Home.route) {
                                            popUpTo(NavigationScreen.Onboarding.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(NavigationScreen.Home.route) {
                                HomeScreen(
                                    newsList = newsArticles,
                                    projectsList = developmentProjects,
                                    socialPostsList = socialPosts,
                                    promisesList = promises,
                                    onNavigate = { screen -> navController.navigate(screen.route) }
                                )
                            }

                            composable(NavigationScreen.PromiseTracker.route) {
                                PromiseTrackerScreen(
                                    promises = promises,
                                    villages = villages,
                                    onPromiseClick = { pId ->
                                        navController.navigate("promise_detail/$pId")
                                    },
                                    onSubmitEvidenceClick = { pId, pTitle ->
                                        navController.navigate("promise_detail/$pId")
                                    }
                                )
                            }

                            composable(
                                route = NavigationScreen.PromiseDetail.route,
                                arguments = listOf(navArgument("promiseId") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val pId = backStackEntry.arguments?.getString("promiseId")
                                val promise = promises.find { it.id == pId }
                                PromiseDetailScreen(
                                    promise = promise,
                                    onBackClick = { navController.popBackStack() },
                                    onSubmitEvidence = { promiseId, promiseTitle, name, mobile, village, type, info, file ->
                                        viewModel.submitPromiseEvidence(
                                            promiseId = promiseId,
                                            promiseTitle = promiseTitle,
                                            userName = name,
                                            userMobile = mobile,
                                            village = village,
                                            submissionType = type,
                                            infoText = info,
                                            fileUrl = file,
                                            onComplete = { _ -> }
                                        )
                                    }
                                )
                            }


                            composable(NavigationScreen.Assembly198.route) {
                                Assembly198Screen(
                                    villages = villages,
                                    projects = developmentProjects,
                                    onVillageClick = { vId ->
                                        navController.navigate("village_detail/$vId")
                                    }
                                )
                            }

                            composable(NavigationScreen.VillageDirectory.route) {
                                VillageDirectoryScreen(
                                    villages = villages,
                                    onVillageClick = { vId ->
                                        navController.navigate("village_detail/$vId")
                                    }
                                )
                            }

                            composable(
                                route = NavigationScreen.VillageDetail.route,
                                arguments = listOf(navArgument("villageId") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val vId = backStackEntry.arguments?.getString("villageId")
                                val village = villages.find { it.id == vId }
                                VillageDetailScreen(
                                    village = village,
                                    projects = developmentProjects,
                                    schools = schools
                                )
                            }

                            composable(NavigationScreen.AiAssistant.route) {
                                AiAssistantScreen(
                                    chatMessages = chatMessages,
                                    isAiThinking = isAiThinking,
                                    onSendMessage = { query -> viewModel.sendAiUserMessage(query) },
                                    onSpeakText = { text -> viewModel.speakHindi(text) },
                                    onStopSpeak = { viewModel.stopSpeaking() }
                                )
                            }

                            composable(NavigationScreen.Complaints.route) {
                                ComplaintScreen(
                                    complaints = complaints,
                                    onSubmitComplaint = { title, cat, vlg, panch, ward, name, mob, desc, onDone ->
                                        viewModel.submitComplaint(title, cat, vlg, panch, ward, name, mob, desc, "", onDone)
                                    }
                                )
                            }

                            composable(NavigationScreen.DevelopmentTracker.route) {
                                DevelopmentTrackerScreen(projects = developmentProjects)
                            }

                            composable(NavigationScreen.EducationHealth.route) {
                                EducationHealthScreen(schools = schools, healthCentres = healthCentres)
                            }

                            composable(NavigationScreen.GovtSchemes.route) {
                                GovtSchemesScreen(schemes = govtSchemes)
                            }

                            composable(NavigationScreen.ContactsDirectory.route) {
                                ContactsDirectoryScreen(contacts = publicContacts, legalInfos = legalInfos)
                            }

                            composable(NavigationScreen.News.route) {
                                NewsScreen(newsList = newsArticles)
                            }

                            composable(NavigationScreen.SocialStudio.route) {
                                SocialStudioScreen(
                                    socialPosts = socialPosts,
                                    onCreatePost = { type, title, msg, cap, name, date, temp, hash, onDone ->
                                        viewModel.createSocialPost(type, title, msg, cap, name, date, temp, hash, onDone)
                                    },
                                    onGenerateAiPost = { cat, name, det, callback ->
                                        viewModel.generateAiSocialPost(cat, name, det, callback)
                                    }
                                )
                            }

                            composable(NavigationScreen.Team.route) {
                                TeamScreen(
                                    teamMembers = teamMembers,
                                    onMemberClick = {}
                                )
                            }

                            composable(NavigationScreen.AdminDashboard.route) {
                                AdminDashboardScreen(
                                    adminRole = adminRole,
                                    complaints = complaints,
                                    socialLinks = socialLinks,
                                    auditLogs = auditLogs,
                                    promises = promises,
                                    promiseSubmissions = promiseSubmissions,
                                    onEscalateComplaint = { cId, dept, ref ->
                                        viewModel.escalateComplaint(cId, dept, ref)
                                    },
                                    onAddSocialLink = { plat, name, url ->
                                        viewModel.addSocialLink(plat, name, url)
                                    },
                                    onAddPublicContact = { name, desig, dept, off, ph ->
                                        viewModel.addPublicContact(name, desig, dept, off, ph)
                                    },
                                    onAddNews = { title, cat, content ->
                                        viewModel.addNews(title, cat, content)
                                    },
                                    onAddPromise = { title, desc, cat, vill, panch, area, date, by, sType, sUrl, status, pWork, cStat, gap ->
                                        viewModel.addPromise(
                                            title = title, description = desc, category = cat, village = vill,
                                            panchayat = panch, area = area, promiseDate = date, promisedBy = by,
                                            sourceType = sType, sourceUrl = sUrl, status = status,
                                            promisedWork = pWork, currentStatus = cStat, gapDetails = gap,
                                            onSuccess = {}
                                        )
                                    },
                                    onReviewPromiseSubmission = { submission, newStatus, notes ->
                                        viewModel.reviewPromiseSubmission(submission, newStatus, notes, onSuccess = {})
                                    }
                                )
                            }


                            composable(NavigationScreen.ProfileSettings.route) {
                                ProfileSettingsScreen(
                                    userName = userName,
                                    userMobile = userMobile,
                                    userVillage = userVillage,
                                    socialLinks = socialLinks,
                                    savedCount = savedItemIds.size,
                                    onAdminClick = { navController.navigate(NavigationScreen.AdminDashboard.route) }
                                )
                            }

                            composable(NavigationScreen.GlobalSearch.route) {
                                GlobalSearchScreen(
                                    villages = villages,
                                    projects = developmentProjects,
                                    news = newsArticles,
                                    schemes = govtSchemes,
                                    schools = schools,
                                    onVillageClick = { vId -> navController.navigate("village_detail/$vId") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
