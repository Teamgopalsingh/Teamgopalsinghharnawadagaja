package com.example.data.local

import com.example.data.model.*

object SampleDataProvider {

    fun initialVillages(): List<VillageEntity> = listOf(
        VillageEntity(
            id = "v001",
            name = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            tehsil = "पिड़ावा / झालरापाटन",
            district = "झालावाड़",
            assembly = "198 - झालरापाटन",
            schoolCount = 3,
            healthCentreCount = 1,
            waterSchemeStatus = "जल जीवन मिशन टंकी स्वीकृत • मुख्य पाइपलाइन प्रगति पर",
            roadCondition = "मुख्य डामर मार्ग स्वीकृत, आंतरिक सीसी सड़क",
            issuesCount = 2,
            description = "हरनावदा गजा झालरापाटन 198 विधानसभा क्षेत्र का एक प्रमुख ऐतिहासिक एवं सांस्कृतिक गांव है।",
            latitude = 24.582,
            longitude = 76.124,
            isVerified = true,
            source = "ग्राम पंचायत हरनावदा गजा कार्यालय रिकॉर्ड",
            lastUpdated = "10 अगस्त 2026"
        ),
        VillageEntity(
            id = "v002",
            name = "सुनेल",
            panchayat = "ग्राम पंचायत सुनेल",
            tehsil = "पिड़ावा",
            district = "झालावाड़",
            assembly = "198 - झालरापाटन",
            schoolCount = 6,
            healthCentreCount = 1,
            waterSchemeStatus = "पेयजल योजना चालू",
            roadCondition = "राज्य राजमार्ग कनेक्टेड",
            issuesCount = 3,
            description = "सुनेल क्षेत्र का एक व्यापारिक एवं शैक्षणिक केंद्र है।",
            latitude = 24.610,
            longitude = 76.100,
            isVerified = true,
            source = "सार्वजनिक राजस्व रिकॉर्ड",
            lastUpdated = "10 अगस्त 2026"
        ),
        VillageEntity(
            id = "v003",
            name = "पिड़ावा",
            panchayat = "नगर पालिका पिड़ावा",
            tehsil = "पिड़ावा",
            district = "झालावाड़",
            assembly = "198 - झालरापाटन",
            schoolCount = 12,
            healthCentreCount = 2,
            waterSchemeStatus = "शहरी जलप्रदाय योजना",
            roadCondition = "चौड़ी पक्की डामर सड़कें",
            issuesCount = 4,
            description = "पिड़ावा झालरापाटन 198 विधानसभा क्षेत्र का मुख्य उपखंड मुख्यालय है।",
            latitude = 24.625,
            longitude = 76.050,
            isVerified = true,
            source = "उपखंड अधिकारी पिड़ावा रिकॉर्ड",
            lastUpdated = "10 अगस्त 2026"
        ),
        VillageEntity(
            id = "v004",
            name = "झालरापाटन नगर",
            panchayat = "नगर पालिका झालरापाटन",
            tehsil = "झालरापाटन",
            district = "झालावाड़",
            assembly = "198 - झालरापाटन",
            schoolCount = 18,
            healthCentreCount = 3,
            waterSchemeStatus = "कालीसिंध जलप्रदाय परियोजना",
            roadCondition = "उत्कृष्ट 4-लेन व सीसी मार्ग",
            issuesCount = 5,
            description = "झालरापाटन घंटियों का शहर (City of Bells) के रूप में प्रसिद्ध विधानसभा 198 का प्रमुख नगर है।",
            latitude = 24.542,
            longitude = 76.173,
            isVerified = true,
            source = "नगर पालिका झालरापाटन",
            lastUpdated = "10 अगस्त 2026"
        ),
        VillageEntity(
            id = "v005",
            name = "रायपुर",
            panchayat = "ग्राम पंचायत रायपुर",
            tehsil = "रायपुर",
            district = "झालावाड़",
            assembly = "198 - झालरापाटन",
            schoolCount = 5,
            healthCentreCount = 1,
            waterSchemeStatus = "पेयजल टंकी निर्मित",
            roadCondition = "डामरीकृत लिंक रोड",
            issuesCount = 1,
            description = "कृषि एवं बागवानी के लिए प्रसिद्ध गांव।",
            latitude = 24.500,
            longitude = 76.020,
            isVerified = true,
            source = "ग्राम पंचायत रायपुर",
            lastUpdated = "10 अगस्त 2026"
        )
    )

    fun initialDevelopmentProjects(): List<DevelopmentProjectEntity> = listOf(
        DevelopmentProjectEntity(
            id = "dp001",
            title = "हरनावदा गजा मुख्य सड़क चौड़ीकरण एवं डामरीकरण",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            department = "सार्वजनिक निर्माण विभाग (PWD) पिड़ावा",
            category = "सड़क",
            budgetCost = "₹ 1.25 करोड़",
            startDate = "15 मार्च 2026",
            expectedCompletion = "30 सितंबर 2026",
            status = "Under Construction",
            progressPercent = 65,
            description = "गांव हरनावदा गजा की मुख्य सड़क का सुदृढ़ीकरण एवं 2 किमी अतिरिक्त सीसी नाली निर्माण कार्य।",
            beforePhoto = "",
            duringPhoto = "",
            afterPhoto = "",
            isVerified = true,
            source = "PWD पिड़ावा कार्य आदेश सं. 2026/41",
            lastUpdated = "10 अगस्त 2026"
        ),
        DevelopmentProjectEntity(
            id = "dp002",
            title = "जल जीवन मिशन - हरनावदा गजा उच्च जलाशय (टंकी)",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            department = "जन स्वास्थ्य अभियांत्रिकी विभाग (PHED)",
            category = "पानी",
            budgetCost = "₹ 85 लाख",
            startDate = "10 जनवरी 2026",
            expectedCompletion = "15 अगस्त 2026",
            status = "Under Construction",
            progressPercent = 80,
            description = "हर घर नल योजना के तहत 1.5 लाख लीटर क्षमता वाली पेयजल टंकी एवं शुद्ध पेयजल पाइपलाइन।",
            beforePhoto = "",
            duringPhoto = "",
            afterPhoto = "",
            isVerified = true,
            source = "PHED झालावाड़ कार्य आदेश सं. 108",
            lastUpdated = "10 अगस्त 2026"
        ),
        DevelopmentProjectEntity(
            id = "dp003",
            title = "राजकीय उच्च माध्यमिक विद्यालय हरनावदा गजा में 4 नवीन कक्षा-कक्ष",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            department = "समग्र शिक्षा अभियान (Samagra Shiksha)",
            category = "शिक्षा",
            budgetCost = "₹ 38 लाख",
            startDate = "01 जून 2025",
            expectedCompletion = "28 फरवरी 2026",
            status = "Completed",
            progressPercent = 100,
            description = "विद्यार्थियों की सुविधा हेतु 4 सर्वसुविधायुक्त डिजिटल क्लासरूम का निर्माण पूर्ण।",
            beforePhoto = "",
            duringPhoto = "",
            afterPhoto = "",
            isVerified = true,
            source = "समग्र शिक्षा झालावाड़ पूर्णता प्रमाण पत्र",
            lastUpdated = "10 अगस्त 2026"
        ),
        DevelopmentProjectEntity(
            id = "dp004",
            title = "हरनावदा गजा - एनिकट एवं एनडीआरएफ सिंचाई नहर मरम्मत",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            department = "जल संसाधन विभाग (Irrigation)",
            category = "सिंचाई",
            budgetCost = "₹ 45 लाख",
            startDate = "20 अगस्त 2026",
            expectedCompletion = "30 दिसंबर 2026",
            status = "Approved",
            progressPercent = 10,
            description = "कृषकों के खेतों तक पानी पहुँचाने हेतु स्थानीय एनिकट की मरम्मत एवं गाद सफाई कार्य।",
            beforePhoto = "",
            duringPhoto = "",
            afterPhoto = "",
            isVerified = true,
            source = "जल संसाधन विभाग झालावाड़ स्वीकृति आदेश",
            lastUpdated = "10 अगस्त 2026"
        )
    )

    fun initialSchools(): List<SchoolEntity> = listOf(
        SchoolEntity(
            id = "sch001",
            schoolName = "राजकीय उच्च माध्यमिक विद्यालय, हरनावदा गजा",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            category = "कक्षा 1 से 12 (कला व विज्ञान)",
            totalStudents = 340,
            workingTeachers = 14,
            vacantPosts = 2,
            headmasterContact = "9166377972 (विद्यालय सूचना केंद्र)",
            facilities = "कंप्यूटर लैब, डिजिटल क्लासरूम, विशाल खेल मैदान, बाल वाटिका, लाइब्रेरी",
            updates = "विज्ञान संकाय प्रयोगशाला हेतु नवीन उपकरण स्थापित किए गए।",
            isVerified = true,
            source = "शाला दर्पण पोर्टल - राजस्थान शिक्षा विभाग",
            lastUpdated = "10 अगस्त 2026"
        ),
        SchoolEntity(
            id = "sch002",
            schoolName = "राजकीय प्राथमिक विद्यालय (कस्बा), हरनावदा गजा",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            category = "कक्षा 1 से 5",
            totalStudents = 85,
            workingTeachers = 4,
            vacantPosts = 0,
            headmasterContact = "9166047972",
            facilities = "पोषाहार (MDM) रसोई, स्वच्छ पेयजल, खेल सामग्री",
            updates = "मध्याह्न भोजन हेतु नया डाइनिंग शेड स्वीकृत।",
            isVerified = true,
            source = "ब्लॉक शिक्षा अधिकारी पिड़ावा",
            lastUpdated = "10 अगस्त 2026"
        )
    )

    fun initialHealthCentres(): List<HealthCentreEntity> = listOf(
        HealthCentreEntity(
            id = "hc001",
            name = "प्राथमिक स्वास्थ्य केंद्र (PHC) हरनावदा गजा",
            type = "PHC (प्राथमिक स्वास्थ्य केंद्र)",
            village = "हरनावदा गजा",
            services = "ओपीडी, प्रसूति सुविधा, निःशुल्क दवा योजना, टीकाकरण, पैथोलॉजी जांच",
            doctorIncharge = "डॉ. आर. के. शर्मा (चिकित्सा अधिकारी)",
            phoneContact = "9166377972 / 104",
            emergencyHelpline = "108 (एम्बुलेंस सेवा)",
            operates24x7 = true,
            isVerified = true,
            source = "मुख्य चिकित्सा एवं स्वास्थ्य अधिकारी (CMHO) झालावाड़",
            lastUpdated = "10 अगस्त 2026"
        ),
        HealthCentreEntity(
            id = "hc002",
            name = "सामुदायिक स्वास्थ्य केंद्र (CHC) सुनेल",
            type = "CHC (सामुदायिक स्वास्थ्य केंद्र)",
            village = "सुनेल",
            services = "24x7 आपातकालीन, प्रसूति गृह, सर्जरी, एक्स-रे, 30 शैय्या अस्पताल",
            doctorIncharge = "डॉ. एम. एल. मीना (प्रभारी अधिकारी)",
            phoneContact = "07431-282222",
            emergencyHelpline = "108 / 104",
            operates24x7 = true,
            isVerified = true,
            source = "स्वास्थ्य विभाग झालावाड़ निर्देशिका",
            lastUpdated = "10 अगस्त 2026"
        )
    )

    fun initialGovtSchemes(): List<GovtSchemeEntity> = listOf(
        GovtSchemeEntity(
            id = "sc001",
            title = "मुख्यमंत्री किसान सम्मान निधि योजना (राजस्थान)",
            category = "किसान",
            eligibility = "राजस्थान के समस्त छोटे एवं सीमांत किसान (PM-Kisan लाभार्थी)",
            benefit = "वार्षिक ₹2,000 अतिरिक्त राज्य वित्तीय सहायता directly DPT द्वारा खातों में",
            documentsRequired = "जनाधार कार्ड, बैंक पासबुक, जमाबंदी (खसरा नकल)",
            applyProcess = "ई-मित्र केंद्र अथवा राज-किसान साथी पोर्टल द्वारा ऑनलाइन आवेदन",
            officialWebsite = "https://rajkisan.rajasthan.gov.in",
            source = "कृषि विभाग राजस्थान सरकार",
            lastUpdated = "10 अगस्त 2026"
        ),
        GovtSchemeEntity(
            id = "sc002",
            title = "मुख्यमंत्री आयुष्मान आरोग्य योजना (MAAY)",
            category = "स्वास्थ्य",
            eligibility = "जनाधार कार्ड धारक समस्त राजस्थान के नागरिक",
            benefit = "प्रतिवर्ष प्रति परिवार ₹25 लाख तक का निःशुल्क कैशलेस इलाज",
            documentsRequired = "जनाधार कार्ड, आधार कार्ड",
            applyProcess = "निकटतम ई-मित्र अथवा सरकारी अस्पताल में जनाधार से सत्यापन",
            officialWebsite = "https://health.rajasthan.gov.in",
            source = "चिकित्सा एवं स्वास्थ्य विभाग राजस्थान",
            lastUpdated = "10 अगस्त 2026"
        ),
        GovtSchemeEntity(
            id = "sc003",
            title = "प्रधानमंत्री आवास योजना (ग्रामीण)",
            category = "आवास",
            eligibility = "SECC-2011 सूची में शामिल कच्चे मकान वाले अथवा बेघर ग्रामीण परिवार",
            benefit = "₹ 1.20 लाख मकान निर्माण हेतु + 90 दिन मनरेगा मजदूरी + शौचालय प्रोत्साहन",
            documentsRequired = "जनाधार, आधार कार्ड, बैंक खाता, जॉब कार्ड, भूमि स्वामित्व",
            applyProcess = "ग्राम पंचायत विकास अधिकारी (सचिव) के माध्यम से सर्वे व आवेदन",
            officialWebsite = "https://pmayg.nic.in",
            source = "ग्रामीण विकास एवं पंचायती राज विभाग",
            lastUpdated = "10 अगस्त 2026"
        ),
        GovtSchemeEntity(
            id = "sc004",
            title = "मुख्यमंत्री सामाजिक सुरक्षा पेंशन योजना",
            category = "पेंशन",
            eligibility = "55 वर्ष+ महिलाएं, 58 वर्ष+ पुरुष (वृद्धजन, एकल नारी, विशेष योग्यजन)",
            benefit = "प्रतिमाह न्यूनतम ₹ 1,150 पेंशन राशि सीधे बैंक खाते में (प्रतिवर्ष 15% स्वतः वृद्धि)",
            documentsRequired = "जनाधार, आधार, आयु प्रमाण पत्र, बैंक पासबुक",
            applyProcess = "ई-मित्र केंद्र द्वारा SSP पोर्टल पर ऑनलाइन आवेदन",
            officialWebsite = "https://ssp.rajasthan.gov.in",
            source = "सामाजिक न्याय एवं अधिकारिता विभाग",
            lastUpdated = "10 अगस्त 2026"
        )
    )

    fun initialPublicContacts(): List<PublicContactEntity> = listOf(
        PublicContactEntity(
            id = "pc001",
            name = "राजस्थान राजस्थान मुख्यमंत्री हेल्पलाइन",
            designation = "जनसमस्या निवारण केंद्र (24x7)",
            department = "मुख्यमंत्री कार्यालय (CMO Rajasthan)",
            officeAddress = "जयपुर / ऑल राजस्थान टोल-फ्री",
            phone = "181",
            email = "cmhelpline@rajasthan.gov.in",
            category = "सीएम हेल्पलाइन 181",
            isVerified = true,
            source = "राजस्थान सरकार आधिकारिक पोर्टल",
            lastUpdated = "10 अगस्त 2026"
        ),
        PublicContactEntity(
            id = "pc002",
            name = "जिला कलेक्टर एवं जिला मजिस्ट्रेट",
            designation = "जिला प्रमुख प्रशासनिक अधिकारी",
            department = "जिला कलेक्ट्रेट, झालावाड़",
            officeAddress = "कलेक्ट्रेट परिसर, झालावाड़ (राज.)",
            phone = "07432-230401",
            email = "dm-jha-rj@nic.in",
            category = "प्रशासनिक अधिकारी",
            isVerified = true,
            source = "झालावाड़ जिला प्रशासन आधिकारिक निर्देशिका",
            lastUpdated = "10 अगस्त 2026"
        ),
        PublicContactEntity(
            id = "pc003",
            name = "उपखंड अधिकारी (SDM) पिड़ावा",
            designation = "उपखंड मजिस्ट्रेट पिड़ावा",
            department = "राजस्व एवं उपखंड कार्यालय पिड़ावा",
            officeAddress = "उपखंड कार्यालय, पिड़ावा, झालावाड़",
            phone = "07431-282001",
            email = "sdm.pidawa@rajasthan.gov.in",
            category = "प्रशासनिक अधिकारी",
            isVerified = true,
            source = "पिड़ावा उपखंड कार्यालय निर्देशिका",
            lastUpdated = "10 अगस्त 2026"
        ),
        PublicContactEntity(
            id = "pc004",
            name = "अधिशासी अभियंता (XEN) PWD",
            designation = "सार्वजनिक निर्माण विभाग प्रभारी",
            department = "PWD पिड़ावा / झालावाड़",
            officeAddress = "PWD कार्यालय पिड़ावा",
            phone = "07431-282120",
            email = "xen.pwd.pidawa@rajasthan.gov.in",
            category = "सड़क एवं निर्माण विभाग",
            isVerified = true,
            source = "PWD राजस्थान निर्देशिका",
            lastUpdated = "10 अगस्त 2026"
        ),
        PublicContactEntity(
            id = "pc005",
            name = "सहायक अभियंता (AEN) PHED (पानी)",
            designation = "पेयजल एवं जल जीवन मिशन प्रभारी",
            department = "PHED पिड़ावा",
            officeAddress = "PHED पिड़ावा कार्यालय",
            phone = "07431-282150",
            email = "aen.phed.pidawa@rajasthan.gov.in",
            category = "पेयजल विभाग",
            isVerified = true,
            source = "PHED राजस्थान सार्वजनिक रिकॉर्ड",
            lastUpdated = "10 अगस्त 2026"
        ),
        PublicContactEntity(
            id = "pc006",
            name = "टीम गोपालसिंह जनसंपर्क कार्यालय",
            designation = "सामुदायिक सेवा केंद्र हरनावदा गजा",
            department = "टीम गोपालसिंह हेल्पलाइन",
            officeAddress = "मुख्य चौराहा, हरनावदा गजा, झालावाड़",
            phone = "9166377972",
            email = "teamgopalsinghharnawadagaja@gmail.com",
            category = "टीम गोपालसिंह संपर्क",
            isVerified = true,
            source = "टीम गोपालसिंह अधिकृत केंद्र",
            lastUpdated = "10 अगस्त 2026"
        )
    )

    fun initialNews(): List<NewsEntity> = listOf(
        NewsEntity(
            id = "nw001",
            title = "हरनावदा गजा में विकास कार्यों का जायजा लिया: जल जीवन मिशन टंकी का कार्य अंतिम चरण में",
            category = "विकास",
            content = "हरनावदा गजा गांव में पेयजल संकट के स्थायी समाधान हेतु चल रहे उच्च जलाशय (पानी की टंकी) के कार्य का निरीक्षण किया गया। अधिकारियों को गुणवत्तापूर्ण कार्य व समय सीमा में पूर्ण करने के निर्देश दिए गए।",
            date = "10 अगस्त 2026",
            author = "टीम गोपालसिंह मीडिया",
            imageUrl = "",
            isVerified = true,
            source = "टीम गोपालसिंह प्रेस रिलीज"
        ),
        NewsEntity(
            id = "nw002",
            title = "झालरापाटन 198 विधानसभा: राजकीय उच्च माध्यमिक विद्यालय में नवीन विज्ञान प्रयोगशाला का उद्घाटन",
            category = "शिक्षा",
            content = "ग्रामीण क्षेत्र के विद्यार्थियों को आधुनिक विज्ञान शिक्षा सुलभ कराने हेतु हरनावदा गजा विद्यालय में सुसज्जित प्रयोगशाला का शुभारंभ किया गया।",
            date = "05 अगस्त 2026",
            author = "टीम गोपालसिंह शिक्षा सेल",
            imageUrl = "",
            isVerified = true,
            source = "विद्यालय विकास समिति"
        )
    )

    fun initialTeamMembers(): List<TeamMemberEntity> = listOf(
        TeamMemberEntity(
            id = "tm001",
            name = "गोपाल सिंह",
            role = "संरक्षक एवं मुख्य जनसेवक",
            areaWard = "हरनावदा गजा - झालरापाटन 198",
            phone = "9166377972",
            whatsapp = "9166377972",
            photoUrl = "",
            isActive = true,
            digitalCardCode = "TGS-198-001"
        ),
        TeamMemberEntity(
            id = "tm002",
            name = "टीम सह-संयोजक",
            role = "ग्राम विकास एवं शिकायत प्रभारी",
            areaWard = "हरनावदा गजा क्षेत्र",
            phone = "9166047972",
            whatsapp = "9166047972",
            photoUrl = "",
            isActive = true,
            digitalCardCode = "TGS-198-002"
        )
    )

    fun initialSocialPosts(): List<SocialPostEntity> = listOf(
        SocialPostEntity(
            id = "sp001",
            postType = "Birthday",
            title = "जन्मदिन की अनंत हार्दिक शुभकामनाएँ",
            message = "टीम गोपालसिंह की ओर से आपको जन्मदिन की बहुत-बहुत बधाई एवं मंगलकामनाएं! ईश्वर आपको दीर्घायु व उत्तम स्वास्थ्य प्रदान करे।",
            caption = "हार्दिक बधाई व शुभकामनाएँ! 💐 #TeamGopalSingh #HarnavadaGaja #Jhalrapatan198",
            personName = "रमेश चंद शर्मा",
            eventDate = "10 अगस्त 2026",
            templateId = "royal_saffron",
            status = "Approved",
            scheduledAt = "10 अगस्त 2026 09:00 AM"
        ),
        SocialPostEntity(
            id = "sp002",
            postType = "Development",
            title = "हरनावदा गजा विकास अपडेट",
            message = "गांव की आवाज़ • गांव का विकास! हरनावदा गजा में मुख्य सड़क चौड़ीकरण एवं सीसी नाली निर्माण कार्य तीव्र गति से जारी।",
            caption = "सबका साथ, गांव का विकास! 🏗️ #HarnavadaGaja #Jhalrapatan198 #Development",
            eventDate = "10 अगस्त 2026",
            templateId = "development_navy",
            status = "Published",
            scheduledAt = "10 अगस्त 2026 08:00 AM"
        )
    )

    fun initialLegalInfo(): List<LegalInfoEntity> = listOf(
        LegalInfoEntity(
            id = "leg001",
            category = "सूचना का अधिकार (RTI Act 2005)",
            title = "सरकारी विभागों से सूचना प्राप्त करने का संवैधानिक अधिकार",
            summary = "नागरिक किसी भी सरकारी विभाग, विकास योजना, बजट आवंटन एवं कार्य गुणवत्ता की प्रमाणित प्रतिलिपि RTI आवेदन देकर प्राप्त कर सकते हैं।",
            processSteps = "1. लोक सूचना अधिकारी (PIO) के नाम सादे कागज पर आवेदन लिखें।\n2. ₹10 का पोस्टल आर्डर/स्टाम्प संलग्न करें।\n3. 30 दिवस में सूचना न मिलने पर प्रथम अपील अधिकारी को नि:शुल्क प्रथम अपील प्रस्तुत करें।",
            helplineNumber = "181 / RTI Online Rajasthan Portal"
        ),
        LegalInfoEntity(
            id = "leg002",
            category = "राजस्थान लोक सेवा गारंटी अधिनियम 2011",
            title = "तय समय सीमा में सरकारी सेवाएं प्राप्त करने का कानूनी हक",
            summary = "जाति प्रमाण पत्र, मूल निवास, पानी कनेक्शन, नामांतरण, राशन कार्ड आदि सरकारी सेवाएं निश्चित समय सीमा में जारी करना अनिवार्य है।",
            processSteps = "1. ई-मित्र या संबंधित विभाग में रसीद प्राप्त करें।\n2. निर्धारित समय सीमा में काम न होने पर प्रथम अपील अधिकारी को शिकायत करें।\n3. दोषी अधिकारी पर ₹250 से ₹5000 तक का जुर्माना लगाने का प्रावधान है।",
            helplineNumber = "181"
        ),
        LegalInfoEntity(
            id = "leg003",
            category = "राजस्थान संपर्क हेल्पलाइन (CM Helpline 181)",
            title = "विभाग की अनदेखी पर सीधे मुख्यमंत्री कार्यालय में शिकायत दर्ज करें",
            summary = "यदि स्थानीय विभाग (पानी, बिजली, सड़क, स्वास्थ्य, पंचायत) में आपकी जनसमस्या का समाधान नहीं होता है तो 181 पर नि शुल्क शिकायत दर्ज कराएं।",
            processSteps = "1. टोल-फ्री 181 पर कॉल करें अथवा Sampark Portal / App पर ऑनलाइन शिकायत दर्ज करें।\n2. आपको प्राप्त शिकायत ID से स्थिति ट्रैक करें।\n3. असंतोषजनक समाधान मिलने पर री-ओपन (Re-open) दर्ज कराएं।",
            helplineNumber = "181"
        )
    )

    fun initialSocialLinks(): List<SocialLinkEntity> = listOf(
        SocialLinkEntity("sl001", "WhatsApp", "टीम गोपालसिंह व्हाट्सएप्प ग्रुप", "https://chat.whatsapp.com/sample", true),
        SocialLinkEntity("sl002", "Facebook", "टीम गोपालसिंह फेसबुक पेज", "https://facebook.com/teamgopalsinghharnawadagaja", true),
        SocialLinkEntity("sl003", "Instagram", "टीम गोपालसिंह इंस्टाग्राम", "https://instagram.com/teamgopalsinghharnawadagaja", true),
        SocialLinkEntity("sl004", "YouTube", "टीम गोपालसिंह यूट्यूब चैनल", "https://youtube.com/@teamgopalsingh198", true),
        SocialLinkEntity("sl005", "X / Twitter", "टीम गोपालसिंह X हैंडल", "https://x.com/teamgopalsingh", true)
    )

    fun initialComplaints(): List<ComplaintEntity> = listOf(
        ComplaintEntity(
            id = "JHL-198-2026-001",
            title = "वार्ड नं. 3 में पेयजल पाइपलाइन लीक मरम्मत",
            category = "पानी",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            wardArea = "वार्ड नं. 3, बाज़ार चौक",
            userName = "विक्रम सिंह",
            userMobile = "9166377972",
            description = "मुख्य पेयजल लाइन में रिसाव होने से पेयजल आपूर्ति प्रभावित हो रही है। कृपया शीघ्रातिशीघ्र सुधार कराएं।",
            status = "संबंधित विभाग को भेजी गई",
            timelineStepsJson = """[{"status":"प्राप्त","date":"08 अगस्त 2026","remark":"टीम गोपालसिंह केंद्र में दर्ज"},{"status":"जांच में","date":"09 अगस्त 2026","remark":"स्थानीय प्रतिनिधि द्वारा भौतिक सत्यापन"},{"status":"संबंधित विभाग को भेजी गई","date":"10 अगस्त 2026","remark":"सहायक अभियंता (AEN) PHED पिड़ावा को आधिकारिक पत्र प्रेषित"}]""",
            isEscalated = true,
            escalationDepartment = "PHED पिड़ावा (जल स्वास्थ्य अभियांत्रिकी विभाग) & CM Helpline 181",
            dispatchReferenceNumber = "TGS/PHED/2026/089",
            createdAt = System.currentTimeMillis() - 86400000L
        )
    )

    fun initialPromises(): List<PromiseEntity> = listOf(
        PromiseEntity(
            id = "PRM-198-001",
            promiseId = "PRM-198-001",
            title = "हरनावदा गजा से सुनेल मुख्य डामर मार्ग चौड़ीकरण व सुदृढ़ीकरण",
            description = "हरनावदा गजा को सुनेल मुख्य मार्ग से जोड़ने वाले 8 किमी मार्ग को 7 मीटर चौड़ा डामरीकृत राज्य लिंक रोड बनाने की घोषणा।",
            category = "सड़क",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            area = "पिड़ावा / झालरापाटन",
            assembly = "198 - झालरापाटन",
            promiseDate = "15 नवंबर 2023",
            promisedBy = "सार्वजनिक चुनाव घोषणा पत्र / जनसभा",
            sourceType = "सार्वजनिक घोषणा व आधिकारिक PWD प्रस्ताव",
            sourceUrl = "https://pwd.rajasthan.gov.in/public_notices/jhalawar_198",
            evidenceUrl = "",
            status = "प्रगति में",
            promisedWork = "8 किमी डामर सड़क निर्माण, 7 मीटर चौड़ाई एवं दोनों ओर जल निकासी नाली स्वीकृत।",
            currentVerifiedStatus = "PWD द्वारा ₹4.20 करोड़ का टेंडर जारी; 4.5 किमी मिट्टी-कंक्रीट सब-बेस कार्य पूर्ण, अर्थवर्क जारी।",
            gapDetails = "स्वीकृत योजना के अनुसार 8 किमी में से 4.5 किमी कार्य पूर्ण हो चुका है, शेष डामरीकरण बरसात के बाद प्रस्तावित है।",
            timelineJson = """[
                {"stage":"वादा","date":"15 नवं 2023","proof":"सार्वजनिक रैली व घोषणा पत्र पृष्ठ 12"},
                {"stage":"घोषणा/प्रस्ताव","date":"10 जन 2024","proof":"PWD झालावाड़ वृत्त कार्यालय पत्रांक 402/2024"},
                {"stage":"स्वीकृति","date":"15 मार्च 2024","proof":"वित्त विभाग प्रशासनिक स्वीकृति ₹4.20 करोड़"},
                {"stage":"कार्य प्रारंभ","date":"02 मई 2024","proof":"ठेकेदार मैसर्स राजस्थान कंस्ट्रक्शन द्वारा वर्क आर्डर जारी"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "PWD AEN पिड़ावा द्वारा 10 अगस्त को भौतिक सत्यापन पूर्ण।"
        ),
        PromiseEntity(
            id = "PRM-198-002",
            promiseId = "PRM-198-002",
            title = "सुनेल में 132 KV विद्युत जीएसएस (GSS) उपकेंद्र स्थापना",
            description = "सुनेल व आसपास के 25 गांवों में कम वोल्टेज व अघोषित बिजली कटौती की समस्या समाधान हेतु नए 132 KV GSS का निर्माण।",
            category = "बिजली",
            village = "सुनेल",
            panchayat = "ग्राम पंचायत सुनेल",
            area = "पिड़ावा",
            assembly = "198 - झालरापाटन",
            promiseDate = "20 अक्टूबर 2023",
            promisedBy = "किसान महापंचायत सार्वजनिक मंच",
            sourceType = "आधिकारिक दस्तावेज़",
            sourceUrl = "https://energy.rajasthan.gov.in/rvpn",
            evidenceUrl = "",
            status = "स्वीकृत",
            promisedWork = "132 KV GSS सब-स्टेशन का निर्माण एवं 33 KV फीडर लाइनों का सुदृढ़ीकरण।",
            currentVerifiedStatus = "भूमि आवंटन 20 बीघा राजस्व बोर्ड सुनेल द्वारा पूर्ण; RVPNL द्वारा ₹12.5 करोड़ की वित्तीय स्वीकृति जारी।",
            gapDetails = "भूमि हस्तांतरण पूर्ण हो चुका है। टेंडर प्रक्रिया अंतिम चरण में है, सिविल निर्माण कार्य शुरू होना शेष है।",
            timelineJson = """[
                {"stage":"वादा","date":"20 अक्टू 2023","proof":"किसान सम्मेलन सार्वजनिक घोषणा"},
                {"stage":"घोषणा/प्रस्ताव","date":"05 फर 2024","proof":"ऊर्जा विभाग पत्रांक E-198/2024"},
                {"stage":"स्वीकृति","date":"22 जून 2024","proof":"RVPNL बोर्ड बैठक मद संख्या 88"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "भूमि खसरा नं. 412 सुनेल का सीमांकन पूर्ण।"
        ),
        PromiseEntity(
            id = "PRM-198-003",
            promiseId = "PRM-198-003",
            title = "हरनावदा गजा उच्च माध्यमिक विद्यालय में विज्ञान व कृषि संकाय स्वीकृति",
            description = "ग्रामीण विद्यार्थियों को 10वीं के बाद उच्च शिक्षा हेतु दूर न जाना पड़े, इसलिए स्कूल में साइंस व एग्रीकल्चर स्ट्रीम शुरू करने का वादा।",
            category = "शिक्षा",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            area = "पिड़ावा / झालरापाटन",
            assembly = "198 - झालरापाटन",
            promiseDate = "05 सितंबर 2023",
            promisedBy = "शिक्षक दिवस जनसमस्या निवारण शिविर",
            sourceType = "आधिकारिक दस्तावेज़",
            sourceUrl = "https://education.rajasthan.gov.in",
            evidenceUrl = "",
            status = "पूर्ण",
            promisedWork = "रा.उ.मा.वि. हरनावदा गजा में विज्ञान (Maths/Bio) एवं कृषि विज्ञान (Agriculture) संकाय प्रारंभ करना।",
            currentVerifiedStatus = "माध्यमिक शिक्षा निदेशालय बीकानेर द्वारा आदेश जारी; 2 व्याख्याता पदस्थापित, प्रयोगशाला उपकरण वितरित।",
            gapDetails = "वादा शत-प्रतिशत पूर्ण। कक्षा 11 में 42 विद्यार्थियों का दाखिला हो चुका है।",
            timelineJson = """[
                {"stage":"वादा","date":"05 सितं 2023","proof":"शिक्षक दिवस कार्यक्रम घोषणा"},
                {"stage":"घोषणा/प्रस्ताव","date":"12 नवं 2023","proof":"डीईओ झालावाड़ प्रस्ताव क्रमांक 901"},
                {"stage":"स्वीकृति","date":"28 जन 2024","proof":"शिक्षा विभाग बजट स्वीकृति आदेश 102/2024"},
                {"stage":"कार्य प्रारंभ","date":"01 अप्रैल 2024","proof":"नवीन भवन निर्माण कार्य"},
                {"stage":"कार्य पूर्ण","date":"01 जुलाई 2024","proof":"सत्र 2024-25 से कक्षाएं प्रारंभ व स्टाफ नियुक्ति"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "शाला दर्पण पोर्टल पर संकाय प्रदर्शित।"
        ),
        PromiseEntity(
            id = "PRM-198-004",
            promiseId = "PRM-198-004",
            title = "पिड़ावा उपखंड चिकित्सालय में ट्रॉमा सेंटर व 24x7 इमरजेंसी सेवा",
            description = "पिड़ावा स्टेट हाईवे पर हादसों के तुरंत इलाज हेतु 30 बेड का ट्रॉमा केयर यूनिट और विशेषज्ञ डॉक्टरों की तैनाती।",
            category = "स्वास्थ्य",
            village = "पिड़ावा",
            panchayat = "नगर पालिका पिड़ावा",
            area = "पिड़ावा",
            assembly = "198 - झालरापाटन",
            promiseDate = "10 दिसंबर 2023",
            promisedBy = "स्वास्थ्य अधिकार यात्रा एवं ज्ञापन",
            sourceType = "विश्वासयोग्य समाचार व चिकित्सा विभाग ज्ञापन",
            sourceUrl = "",
            evidenceUrl = "",
            status = "लंबित",
            promisedWork = "पिड़ावा सब-डिविजनल हॉस्पिटल में 30 बेड ट्रॉमा सेंटर, डिजिटल एक्स-रे व 2 सर्जन पदों की स्वीकृति।",
            currentVerifiedStatus = "चिकित्सा विभाग को प्रस्ताव प्रेषित किया गया है। बजट घोषणा में शामिल करने हेतु अनुशंसा की गई है।",
            gapDetails = "प्रस्ताव राज्य स्तर पर विचाराधीन है। अभी तक वित्तीय स्वीकृति जारी नहीं हुई है।",
            timelineJson = """[
                {"stage":"वादा","date":"10 दिसं 2023","proof":"सार्वजनिक मांग पत्र ज्ञापन"},
                {"stage":"घोषणा/प्रस्ताव","date":"18 मार्च 2024","proof":"CMHO झालावाड़ द्वारा निदेशालय को प्रेषित प्रस्ताव 314"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "चिकित्सा विभाग से निरंतर पत्राचार जारी।"
        ),
        PromiseEntity(
            id = "PRM-198-005",
            promiseId = "PRM-198-005",
            title = "कालीसिंध नदी लिंक से झालरापाटन-रायपुर सिंचित क्षेत्र विस्तार परियोजना",
            description = "क्षेत्र के 40 गांवों में रबी फसल हेतु सूक्ष्म सिंचाई (Micro Irrigation) व नहरी पानी पहुंचाने की वृहद जल परियोजना।",
            category = "सिंचाई",
            village = "रायपुर",
            panchayat = "ग्राम पंचायत रायपुर",
            area = "रायपुर",
            assembly = "198 - झालरापाटन",
            promiseDate = "25 अक्टूबर 2023",
            promisedBy = "किसान रैली सार्वजनिक घोषणा",
            sourceType = "सार्वजनिक घोषणा व जल संसाधन विभाग रिकॉर्ड",
            sourceUrl = "",
            evidenceUrl = "",
            status = "प्रगति में",
            promisedWork = "40 गांवों की 15,000 हेक्टेयर भूमि को कालीसिंध बांध से लिफ्ट इरिगेशन नेटवर्क द्वारा सिंचित करना।",
            currentVerifiedStatus = "डीपीआर (DPR) ₹185 करोड़ की तैयार; प्राथमिक सर्वे व जीआईएस मैपिंग पूर्ण, भूमि अधिग्रहण सूचना जारी।",
            gapDetails = "सर्वे एवं डीपीआर पूर्ण। जल संसाधन विभाग झालावाड़ द्वारा टेंडर आमंत्रण की प्रक्रिया जारी है।",
            timelineJson = """[
                {"stage":"वादा","date":"25 अक्टू 2023","proof":"किसान सम्मेलन मंच घोषणा"},
                {"stage":"घोषणा/प्रस्ताव","date":"15 फर 2024","proof":"जल संसाधन विभाग संभाग कोटा फाइल 88/WR"},
                {"stage":"स्वीकृति","date":"30 मई 2024","proof":"राज्य जल संसाधन बोर्ड तकनीकी स्वीकृति"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "सिंचाई विभाग अधीक्षण अभियंता कार्यालय से सत्यापित।"
        ),
        PromiseEntity(
            id = "PRM-198-006",
            promiseId = "PRM-198-006",
            title = "झालरापाटन नगर में खेल स्टेडियम व आधुनिक इनडोर स्पोर्ट्स कॉम्प्लेक्स",
            description = "झालरापाटन 198 के युवाओं हेतु एथलेटिक्स ट्रैक, बास्केटबॉल कोर्ट, बैडमिंटन इनडोर हॉल व जिम युक्त स्टेडियम।",
            category = "खेल",
            village = "झालरापाटन नगर",
            panchayat = "नगर पालिका झालरापाटन",
            area = "झालरापाटन",
            assembly = "198 - झालरापाटन",
            promiseDate = "29 अगस्त 2023",
            promisedBy = "राष्ट्रीय खेल दिवस युवा संवाद",
            sourceType = "आधिकारिक खेल परिषद रिकॉर्ड",
            sourceUrl = "https://sports.rajasthan.gov.in",
            evidenceUrl = "",
            status = "सत्यापन आवश्यक",
            promisedWork = "₹5.00 करोड़ की लागत से मिनी स्पोर्ट्स कॉम्प्लेक्स एवं 400 मीटर सिंथेटिक ट्रैक।",
            currentVerifiedStatus = "नगर पालिका झालरापाटन द्वारा भूमि चिह्नित की गई है, परंतु राज्य क्रीड़ा परिषद स्वीकृति का विवरण प्रतीक्षित है।",
            gapDetails = "स्थानीय निवासियों से प्राप्त जानकारी अनुसार सीमांकन कार्य हुआ है; आधिकारिक बजट स्वीकृति का सत्यापन किया जा रहा है।",
            timelineJson = """[
                {"stage":"वादा","date":"29 अग 2023","proof":"युवा खेल प्रोत्साहन समारोह"},
                {"stage":"घोषणा/प्रस्ताव","date":"10 नवं 2023","proof":"नगर पालिका झालरापाटन प्रस्ताव सं. 44"}
            ]""",
            verificationStatus = "Requires Verification",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "राजस्थान राज्य क्रीड़ा परिषद से आधिकारिक पुष्टि हेतु पत्राचार भेजा गया है।"
        ),
        PromiseEntity(
            id = "PRM-198-007",
            promiseId = "PRM-198-007",
            title = "सुनेल मंडी क्षेत्र में मुख्यमंत्री निःशुल्क अन्नपूर्णा रसोई व शेड विस्तार",
            description = "मंडी में आने वाले किसानों, हम्मालों व श्रमिकों हेतु ₹8 में पौष्टिक भोजन व बारिश/धूप से बचाव हेतु शेड निर्माण।",
            category = "अन्य",
            village = "सुनेल",
            panchayat = "ग्राम पंचायत सुनेल",
            area = "पिड़ावा",
            assembly = "198 - झालरापाटन",
            promiseDate = "12 नवंबर 2023",
            promisedBy = "मंडी व्यापारी व मजदूर महासंघ संवाद",
            sourceType = "आधिकारिक दस्तावेज़",
            sourceUrl = "",
            evidenceUrl = "",
            status = "पूर्ण",
            promisedWork = "कृषि उपज मंडी सुनेल परिसर में अन्नपूर्णा रसोई भवन व 200 मीटर लंबा कवर्ड शेड निर्माण।",
            currentVerifiedStatus = "रसोई सुचारू रूप से संचालित (प्रतिदिन 300+ लाभार्थी); मंडी शेड निर्माण पूर्ण हो चुका है।",
            gapDetails = "वादा पूर्ण। दैनिक गुणवत्ता जांच नगर पालिका एवं खाद्य निरीक्षक द्वारा की जाती है।",
            timelineJson = """[
                {"stage":"वादा","date":"12 नवं 2023","proof":"मंडी परिसर जनसभा"},
                {"stage":"घोषणा/प्रस्ताव","date":"05 दिसं 2023","proof":"कृषि विपणन बोर्ड झालावाड़ कार्य योजना"},
                {"stage":"स्वीकृति","date":"15 फर 2024","proof":"मंडी समिति स्वीकृति ₹85 लाख"},
                {"stage":"कार्य प्रारंभ","date":"10 मार्च 2024","proof":"निर्माण प्रारंभ"},
                {"stage":"कार्य पूर्ण","date":"20 जून 2024","proof":"रसोई व शेड लोकार्पण पूर्ण"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "मंडी सचिव सुनेल द्वारा सत्यापित।"
        ),
        PromiseEntity(
            id = "PRM-198-008",
            promiseId = "PRM-198-008",
            title = "हरनावदा गजा में अमृत सरोव जलाशय सौंदर्यीकरण व पक्का घाट निर्माण",
            description = "गांव के ऐतिहासिक तालाब के चारों ओर पेवर ब्लॉक वॉक-वे, रोशनी, वृक्षारोपण व पक्के स्नान घाट का निर्माण।",
            category = "पानी",
            village = "हरनावदा गजा",
            panchayat = "ग्राम पंचायत हरनावदा गजा",
            area = "पिड़ावा / झालरापाटन",
            assembly = "198 - झालरापाटन",
            promiseDate = "15 अगस्त 2023",
            promisedBy = "स्वतंत्रता दिवस ग्राम सभा",
            sourceType = "ग्राम पंचायत रिकॉर्ड",
            sourceUrl = "",
            evidenceUrl = "",
            status = "प्रगति में",
            promisedWork = "अमृत सरोवर योजनांतर्गत ₹48 लाख की लागत से घाट, वॉकिंग ट्रैक व जल संचयन जीर्णोद्धार।",
            currentVerifiedStatus = "घाट निर्माण 80% पूर्ण, वॉकिंग पाथवे पेवर ब्लॉक बिछाए जा रहे हैं। सोलर लाइटें स्थापित।",
            gapDetails = "मुख्य घाट व रिटेनिंग वॉल पूर्ण है, पार्क व बैंच स्थापना कार्य प्रगति पर है।",
            timelineJson = """[
                {"stage":"वादा","date":"15 अग 2023","proof":"ग्राम सभा प्रस्ताव संकल्प 5"},
                {"stage":"घोषणा/प्रस्ताव","date":"02 अक्टू 2023","proof":"मनरेगा व अमृत सरोवर प्रशासनिक स्वीकृति"},
                {"stage":"स्वीकृति","date":"10 नवं 2023","proof":"जिला परिषद झालावाड़ तकनीकी स्वीकृति"},
                {"stage":"कार्य प्रारंभ","date":"12 जन 2024","proof":"भूमि पूजन एवं खुदाई प्रारंभ"}
            ]""",
            verificationStatus = "Verified",
            lastVerifiedAt = "10 अगस्त 2026",
            adminNotes = "ग्राम विकास अधिकारी हरनावदा गजा द्वारा 10 अगस्त को स्थल निरीक्षण किया गया।"
        )
    )

    fun initialPromiseSubmissions(): List<PromiseSubmissionEntity> = listOf(
        PromiseSubmissionEntity(
            id = "sub_101",
            promiseId = "PRM-198-001",
            promiseTitle = "हरनावदा गजा से सुनेल मुख्य डामर मार्ग चौड़ीकरण व सुदृढ़ीकरण",
            userName = "दीपक धाकड़",
            userMobile = "9829012345",
            village = "हरनावदा गजा",
            submissionType = "📷 फोटो",
            infoText = "सड़क का सब-बेस कार्य पूर्ण हो गया है। हाल ही में कंक्रीट बिछाने की फोटो संलग्न है।",
            fileUrl = "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3",
            status = "Approved",
            submittedAt = System.currentTimeMillis() - 172800000L,
            adminNotes = "सत्यापित एवं स्वीकृत। रिकॉर्ड में जोड़ा गया।"
        ),
        PromiseSubmissionEntity(
            id = "sub_102",
            promiseId = "PRM-198-002",
            promiseTitle = "सुनेल में 132 KV विद्युत जीएसएस (GSS) उपकेंद्र स्थापना",
            userName = "रमेश चंद गुर्जर",
            userMobile = "9414098765",
            village = "सुनेल",
            submissionType = "📝 जानकारी",
            infoText = "खसरा नंबर 412 में राजस्व विभाग द्वारा बाउंड्री वॉल हेतु खूंटे गाड़ दिए गए हैं।",
            fileUrl = "",
            status = "Pending Verification",
            submittedAt = System.currentTimeMillis() - 86400000L,
            adminNotes = "समीक्षा हेतु लंबित।"
        )
    )

}
