package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
    entities = [
        VillageEntity::class,
        ComplaintEntity::class,
        DevelopmentProjectEntity::class,
        SchoolEntity::class,
        HealthCentreEntity::class,
        GovtSchemeEntity::class,
        PublicContactEntity::class,
        NewsEntity::class,
        TeamMemberEntity::class,
        SocialPostEntity::class,
        AuditLogEntity::class,
        PublicNoticeEntity::class,
        LegalInfoEntity::class,
        SocialLinkEntity::class,
        PromiseEntity::class,
        PromiseSubmissionEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "team_gopal_singh_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
