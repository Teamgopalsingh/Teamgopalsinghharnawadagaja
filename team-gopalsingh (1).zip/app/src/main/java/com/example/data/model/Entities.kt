package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "villages")
data class VillageEntity(
    @PrimaryKey val id: String,
    val name: String,
    val panchayat: String,
    val tehsil: String = "झालावाड़ / पिड़ावा",
    val district: String = "झालावाड़",
    val assembly: String = "198 - झालरापाटन",
    val schoolCount: Int = 0,
    val healthCentreCount: Int = 0,
    val waterSchemeStatus: String = "",
    val roadCondition: String = "",
    val issuesCount: Int = 0,
    val description: String = "",
    val latitude: Double = 24.6,
    val longitude: Double = 76.1,
    val isVerified: Boolean = true,
    val source: String = "लोकप्रिय सार्वजनिक रिकॉर्ड / ग्राम पंचायत",
    val lastUpdated: String = "10 अगस्त 2026"
)

@Entity(tableName = "complaints")
data class ComplaintEntity(
    @PrimaryKey val id: String, // Format: JHL-198-2026-001
    val title: String,
    val category: String, // पानी, सड़क, बिजली, शिक्षा, स्वास्थ्य, कृषि, सिंचाई, etc.
    val village: String,
    val panchayat: String,
    val wardArea: String,
    val userName: String,
    val userMobile: String,
    val description: String,
    val status: String, // प्राप्त, जांच में, संबंधित विभाग को भेजी गई, कार्रवाई जारी, समाधान
    val timelineStepsJson: String = "[]",
    val photoUrl: String = "",
    val isEscalated: Boolean = false,
    val escalationDepartment: String = "", // Jal Shakti Dept / PWD / Jhalawar Collectorate / CM Helpline 181
    val dispatchReferenceNumber: String = "", // Official tracking reference sent to dept
    val feedbackRating: Int = 0,
    val feedbackComment: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "development_projects")
data class DevelopmentProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val village: String,
    val panchayat: String,
    val department: String, // PWD, Public Health, Irrigation, Panchayati Raj
    val category: String, // सड़क, पानी, सिंचाई, भवन, शिक्षा
    val budgetCost: String,
    val startDate: String,
    val expectedCompletion: String,
    val status: String, // Proposed (🟡), Approved (🔵), Under Construction (🟠), Completed (🟢)
    val progressPercent: Int = 0,
    val description: String,
    val beforePhoto: String = "",
    val duringPhoto: String = "",
    val afterPhoto: String = "",
    val isVerified: Boolean = true,
    val source: String = "सार्वजनिक विकास रिपोर्ट",
    val lastUpdated: String = "10 अगस्त 2026"
)

@Entity(tableName = "schools")
data class SchoolEntity(
    @PrimaryKey val id: String,
    val schoolName: String,
    val village: String,
    val panchayat: String,
    val category: String, // राजकीय उच्च माध्यमिक, प्राथमिक, etc.
    val totalStudents: Int,
    val workingTeachers: Int,
    val vacantPosts: Int,
    val headmasterContact: String,
    val facilities: String,
    val updates: String,
    val isVerified: Boolean = true,
    val source: String = "जिला शिक्षा अधिकारी सार्वजनिक रिकॉर्ड",
    val lastUpdated: String = "10 अगस्त 2026"
)

@Entity(tableName = "health_centres")
data class HealthCentreEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // CHC, PHC, उप स्वास्थ्य केंद्र
    val village: String,
    val services: String,
    val doctorIncharge: String,
    val phoneContact: String,
    val emergencyHelpline: String,
    val operates24x7: Boolean = false,
    val isVerified: Boolean = true,
    val source: String = "चिकित्सा एवं स्वास्थ्य विभाग झालावाड़",
    val lastUpdated: String = "10 अगस्त 2026"
)

@Entity(tableName = "govt_schemes")
data class GovtSchemeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // किसान, आवास, पेंशन, छात्रवृत्ति, महिला, रोजगार, स्वास्थ्य
    val eligibility: String,
    val benefit: String,
    val documentsRequired: String,
    val applyProcess: String,
    val officialWebsite: String,
    val source: String = "राजस्थान सरकार जनसूचना पोर्टल",
    val lastUpdated: String = "10 अगस्त 2026"
)

@Entity(tableName = "public_contacts")
data class PublicContactEntity(
    @PrimaryKey val id: String,
    val name: String,
    val designation: String,
    val department: String,
    val officeAddress: String,
    val phone: String,
    val email: String = "",
    val category: String = "विभागीय अधिकारी", // प्रशासनिक, पुलिस, बिजली, पानी, राजस्व, सीएम हेल्पलाइन
    val isVerified: Boolean = true,
    val source: String = "झालावाड़ जिला प्रशासन सार्वजनिक निर्देशिका",
    val lastUpdated: String = "10 अगस्त 2026"
)

@Entity(tableName = "news_articles")
data class NewsEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // विकास, गांव, शिक्षा, स्वास्थ्य, कृषि, जनसमस्या
    val content: String,
    val date: String,
    val author: String = "टीम गोपालसिंह सूचना विंग",
    val imageUrl: String = "",
    val isVerified: Boolean = true,
    val source: String = "टीम गोपालसिंह प्रेस विज्ञप्ति"
)

@Entity(tableName = "team_members")
data class TeamMemberEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val areaWard: String,
    val phone: String,
    val whatsapp: String,
    val photoUrl: String = "",
    val isActive: Boolean = true,
    val digitalCardCode: String = ""
)

@Entity(tableName = "social_posts")
data class SocialPostEntity(
    @PrimaryKey val id: String,
    val postType: String, // Birthday, Anniversary, Festival, SpecialDay, Development, ThankYou, Announcement
    val title: String,
    val message: String,
    val caption: String,
    val personName: String = "",
    val personPhoto: String = "",
    val eventDate: String = "",
    val templateId: String = "royal",
    val mediaUrl: String = "",
    val status: String = "Scheduled", // Draft, Pending, Approved, Scheduled, Published
    val scheduledAt: String = "",
    val hashtags: String = "#TeamGopalSingh #HarnavadaGaja #Jhalrapatan198 #Jhalawar",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val adminUser: String,
    val action: String,
    val module: String,
    val recordId: String,
    val details: String,
    val timestamp: String = "10-08-2026 12:00 PM"
)

@Entity(tableName = "public_notices")
data class PublicNoticeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val publishDate: String,
    val source: String,
    val isVerified: Boolean = true
)

@Entity(tableName = "legal_info")
data class LegalInfoEntity(
    @PrimaryKey val id: String,
    val category: String, // RTI Act, Public Service Guarantee Act, CM Helpline 181 Rules, Legal Rights
    val title: String,
    val summary: String,
    val processSteps: String,
    val helplineNumber: String = "181"
)

@Entity(tableName = "social_links")
data class SocialLinkEntity(
    @PrimaryKey val id: String,
    val platform: String, // Facebook, Instagram, YouTube, Twitter/X, WhatsApp Group
    val name: String,
    val url: String,
    val isActive: Boolean = true
)

@Entity(tableName = "promises")
data class PromiseEntity(
    @PrimaryKey val id: String, // e.g. "PRM-198-001"
    val promiseId: String, // Display Promise ID
    val title: String,
    val description: String,
    val category: String, // सड़क, पानी, बिजली, शिक्षा, स्वास्थ्य, सिंचाई, रोजगार, खेल, आवास, अन्य
    val village: String,
    val panchayat: String,
    val area: String, // e.g. "पिड़ावा / झालरापाटन"
    val assembly: String = "198 - झालरापाटन",
    val promiseDate: String, // e.g. "15 नवंबर 2023"
    val promisedBy: String = "सार्वजनिक घोषणा / घोषणा पत्र",
    val sourceType: String = "आधिकारिक दस्तावेज़", // आधिकारिक दस्तावेज़, सार्वजनिक घोषणा, विश्वसनीय समाचार स्रोत, अन्य प्रमाण
    val sourceUrl: String = "",
    val evidenceUrl: String = "",
    val status: String = "लंबित", // 🟡 लंबित, 🔵 स्वीकृत, 🟠 प्रगति में, 🟢 पूर्ण, ⚪ स्थिति अज्ञात, 🔴 सत्यापन आवश्यक
    val promisedWork: String = "", // वादा: घोषित कार्य/वादा
    val currentVerifiedStatus: String = "", // वर्तमान स्थिति: वर्तमान सत्यापित स्थिति
    val gapDetails: String = "", // अंतर: वादे के बाद हुई कार्रवाई का विवरण
    val timelineJson: String = "[]", // JSON array of timeline steps
    val verificationStatus: String = "Verified", // Verified, Pending Verification, Requires Verification
    val lastVerifiedAt: String = "10 अगस्त 2026",
    val adminNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "promise_submissions")
data class PromiseSubmissionEntity(
    @PrimaryKey val id: String, // e.g. "sub_1001"
    val promiseId: String,
    val promiseTitle: String,
    val userName: String,
    val userMobile: String,
    val village: String,
    val submissionType: String, // 📷 फोटो, 🎥 वीडियो, 📄 दस्तावेज़, 📝 जानकारी
    val infoText: String,
    val fileUrl: String = "",
    val sourceType: String = "नागरिक प्रमाण",
    val status: String = "Pending Verification", // Pending Verification, Approved, Rejected
    val submittedAt: Long = System.currentTimeMillis(),
    val adminNotes: String = ""
)

