package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Villages ---
    @Query("SELECT * FROM villages ORDER BY name ASC")
    fun getAllVillages(): Flow<List<VillageEntity>>

    @Query("SELECT * FROM villages WHERE id = :id LIMIT 1")
    suspend fun getVillageById(id: String): VillageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVillages(villages: List<VillageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVillage(village: VillageEntity)

    // --- Complaints ---
    @Query("SELECT * FROM complaints ORDER BY createdAt DESC")
    fun getAllComplaints(): Flow<List<ComplaintEntity>>

    @Query("SELECT * FROM complaints WHERE userMobile = :mobile ORDER BY createdAt DESC")
    fun getComplaintsByUser(mobile: String): Flow<List<ComplaintEntity>>

    @Query("SELECT * FROM complaints WHERE id = :id LIMIT 1")
    suspend fun getComplaintById(id: String): ComplaintEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: ComplaintEntity)

    @Update
    suspend fun updateComplaint(complaint: ComplaintEntity)

    // --- Development Projects ---
    @Query("SELECT * FROM development_projects ORDER BY id DESC")
    fun getAllDevelopmentProjects(): Flow<List<DevelopmentProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevelopmentProjects(projects: List<DevelopmentProjectEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevelopmentProject(project: DevelopmentProjectEntity)

    // --- Schools ---
    @Query("SELECT * FROM schools ORDER BY schoolName ASC")
    fun getAllSchools(): Flow<List<SchoolEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchools(schools: List<SchoolEntity>)

    // --- Health Centres ---
    @Query("SELECT * FROM health_centres ORDER BY name ASC")
    fun getAllHealthCentres(): Flow<List<HealthCentreEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHealthCentres(centres: List<HealthCentreEntity>)

    // --- Government Schemes ---
    @Query("SELECT * FROM govt_schemes ORDER BY title ASC")
    fun getAllGovtSchemes(): Flow<List<GovtSchemeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGovtSchemes(schemes: List<GovtSchemeEntity>)

    // --- Public Contacts ---
    @Query("SELECT * FROM public_contacts ORDER BY name ASC")
    fun getAllPublicContacts(): Flow<List<PublicContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPublicContacts(contacts: List<PublicContactEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPublicContact(contact: PublicContactEntity)

    // --- News Articles ---
    @Query("SELECT * FROM news_articles ORDER BY id DESC")
    fun getAllNews(): Flow<List<NewsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNews(news: List<NewsEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNewsItem(newsItem: NewsEntity)

    // --- Team Members ---
    @Query("SELECT * FROM team_members WHERE isActive = 1 ORDER BY name ASC")
    fun getAllTeamMembers(): Flow<List<TeamMemberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeamMembers(members: List<TeamMemberEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeamMember(member: TeamMemberEntity)

    // --- Social Posts ---
    @Query("SELECT * FROM social_posts ORDER BY createdAt DESC")
    fun getAllSocialPosts(): Flow<List<SocialPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialPost(post: SocialPostEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialPosts(posts: List<SocialPostEntity>)

    // --- Audit Logs ---
    @Query("SELECT * FROM audit_logs ORDER BY id DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    // --- Public Notices ---
    @Query("SELECT * FROM public_notices ORDER BY id DESC")
    fun getAllPublicNotices(): Flow<List<PublicNoticeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPublicNotices(notices: List<PublicNoticeEntity>)

    // --- Legal Info ---
    @Query("SELECT * FROM legal_info ORDER BY id ASC")
    fun getAllLegalInfo(): Flow<List<LegalInfoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLegalInfo(infoList: List<LegalInfoEntity>)

    // --- Social Links ---
    @Query("SELECT * FROM social_links ORDER BY platform ASC")
    fun getAllSocialLinks(): Flow<List<SocialLinkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialLinks(links: List<SocialLinkEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialLink(link: SocialLinkEntity)

    // --- Promises ---
    @Query("SELECT * FROM promises ORDER BY promiseDate DESC, id DESC")
    fun getAllPromises(): Flow<List<PromiseEntity>>

    @Query("SELECT * FROM promises WHERE id = :id LIMIT 1")
    suspend fun getPromiseById(id: String): PromiseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromises(promises: List<PromiseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromise(promise: PromiseEntity)

    @Update
    suspend fun updatePromise(promise: PromiseEntity)

    @Query("DELETE FROM promises WHERE id = :id")
    suspend fun deletePromiseById(id: String)

    // --- Promise Submissions ---
    @Query("SELECT * FROM promise_submissions ORDER BY submittedAt DESC")
    fun getAllPromiseSubmissions(): Flow<List<PromiseSubmissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromiseSubmissions(submissions: List<PromiseSubmissionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromiseSubmission(submission: PromiseSubmissionEntity)

    @Update
    suspend fun updatePromiseSubmission(submission: PromiseSubmissionEntity)
}

