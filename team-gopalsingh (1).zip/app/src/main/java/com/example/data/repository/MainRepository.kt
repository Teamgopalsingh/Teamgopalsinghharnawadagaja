package com.example.data.repository

import com.example.ai.GeminiAiService
import com.example.data.local.AppDao
import com.example.data.local.SampleDataProvider
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class MainRepository(
    private val appDao: AppDao,
    private val aiService: GeminiAiService = GeminiAiService()
) {

    val villages: Flow<List<VillageEntity>> = appDao.getAllVillages()
    val developmentProjects: Flow<List<DevelopmentProjectEntity>> = appDao.getAllDevelopmentProjects()
    val schools: Flow<List<SchoolEntity>> = appDao.getAllSchools()
    val healthCentres: Flow<List<HealthCentreEntity>> = appDao.getAllHealthCentres()
    val govtSchemes: Flow<List<GovtSchemeEntity>> = appDao.getAllGovtSchemes()
    val publicContacts: Flow<List<PublicContactEntity>> = appDao.getAllPublicContacts()
    val newsArticles: Flow<List<NewsEntity>> = appDao.getAllNews()
    val teamMembers: Flow<List<TeamMemberEntity>> = appDao.getAllTeamMembers()
    val socialPosts: Flow<List<SocialPostEntity>> = appDao.getAllSocialPosts()
    val complaints: Flow<List<ComplaintEntity>> = appDao.getAllComplaints()
    val auditLogs: Flow<List<AuditLogEntity>> = appDao.getAllAuditLogs()
    val publicNotices: Flow<List<PublicNoticeEntity>> = appDao.getAllPublicNotices()
    val legalInfos: Flow<List<LegalInfoEntity>> = appDao.getAllLegalInfo()
    val socialLinks: Flow<List<SocialLinkEntity>> = appDao.getAllSocialLinks()
    val promises: Flow<List<PromiseEntity>> = appDao.getAllPromises()
    val promiseSubmissions: Flow<List<PromiseSubmissionEntity>> = appDao.getAllPromiseSubmissions()

    suspend fun seedInitialDataIfNecessary() = withContext(Dispatchers.IO) {
        val existingVillages = appDao.getAllVillages().first()
        if (existingVillages.isEmpty()) {
            appDao.insertVillages(SampleDataProvider.initialVillages())
            appDao.insertDevelopmentProjects(SampleDataProvider.initialDevelopmentProjects())
            appDao.insertSchools(SampleDataProvider.initialSchools())
            appDao.insertHealthCentres(SampleDataProvider.initialHealthCentres())
            appDao.insertGovtSchemes(SampleDataProvider.initialGovtSchemes())
            appDao.insertPublicContacts(SampleDataProvider.initialPublicContacts())
            appDao.insertNews(SampleDataProvider.initialNews())
            appDao.insertTeamMembers(SampleDataProvider.initialTeamMembers())
            appDao.insertSocialPosts(SampleDataProvider.initialSocialPosts())
            appDao.insertLegalInfo(SampleDataProvider.initialLegalInfo())
            appDao.insertSocialLinks(SampleDataProvider.initialSocialLinks())
            for (complaint in SampleDataProvider.initialComplaints()) {
                appDao.insertComplaint(complaint)
            }
            appDao.insertAuditLog(
                AuditLogEntity(
                    adminUser = "System Seed",
                    action = "INITIALIZE_DATABASE",
                    module = "Core DB",
                    recordId = "v001-v005",
                    details = "हरनावदा गजा व झालरापाटन 198 प्रारंभिक डेटाबेस सेटअप पूर्ण"
                )
            )
        }

        val existingPromises = appDao.getAllPromises().first()
        if (existingPromises.isEmpty()) {
            appDao.insertPromises(SampleDataProvider.initialPromises())
            appDao.insertPromiseSubmissions(SampleDataProvider.initialPromiseSubmissions())
            appDao.insertAuditLog(
                AuditLogEntity(
                    adminUser = "System Seed",
                    action = "SEED_PROMISES",
                    module = "Promise Tracker",
                    recordId = "PRM-198-001-008",
                    details = "झालरापाटन 198 विधानसभा जन-वादा ट्रैकर डेटाबेस प्रारंभिक रिकॉर्ड स्थापित"
                )
            )
        }
    }

    suspend fun addPromise(promise: PromiseEntity, adminUser: String) = withContext(Dispatchers.IO) {
        appDao.insertPromise(promise)
        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "ADD_PROMISE",
                module = "Promise Tracker",
                recordId = promise.id,
                details = "नवीन वादा/घोषणा दर्ज की गई: ${promise.title} (${promise.village})"
            )
        )
    }

    suspend fun updatePromise(promise: PromiseEntity, adminUser: String) = withContext(Dispatchers.IO) {
        appDao.updatePromise(promise)
        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "UPDATE_PROMISE",
                module = "Promise Tracker",
                recordId = promise.id,
                details = "वादा रिकॉर्ड अद्यतन: ${promise.title} | स्थिति: ${promise.status}"
            )
        )
    }

    suspend fun deletePromise(promiseId: String, adminUser: String) = withContext(Dispatchers.IO) {
        appDao.deletePromiseById(promiseId)
        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "DELETE_PROMISE",
                module = "Promise Tracker",
                recordId = promiseId,
                details = "वादा रिकॉर्ड आर्काइव/हटाया गया"
            )
        )
    }

    suspend fun submitPromiseEvidence(
        promiseId: String,
        promiseTitle: String,
        userName: String,
        userMobile: String,
        village: String,
        submissionType: String,
        infoText: String,
        fileUrl: String
    ): String = withContext(Dispatchers.IO) {
        val subId = "sub_${System.currentTimeMillis()}"
        val newSub = PromiseSubmissionEntity(
            id = subId,
            promiseId = promiseId,
            promiseTitle = promiseTitle,
            userName = userName,
            userMobile = userMobile,
            village = village,
            submissionType = submissionType,
            infoText = infoText,
            fileUrl = fileUrl,
            status = "Pending Verification",
            submittedAt = System.currentTimeMillis()
        )
        appDao.insertPromiseSubmission(newSub)
        subId
    }

    suspend fun reviewPromiseSubmission(
        submission: PromiseSubmissionEntity,
        newStatus: String, // Approved or Rejected
        adminUser: String,
        notes: String
    ) = withContext(Dispatchers.IO) {
        val updatedSub = submission.copy(status = newStatus, adminNotes = notes)
        appDao.updatePromiseSubmission(updatedSub)

        if (newStatus == "Approved") {
            val promise = appDao.getPromiseById(submission.promiseId)
            if (promise != null) {
                val updatedPromise = promise.copy(
                    gapDetails = "${promise.gapDetails}\n[नागरिक प्रमाण ${submission.userName}]: ${submission.infoText}",
                    lastVerifiedAt = "10 अगस्त 2026",
                    updatedAt = System.currentTimeMillis()
                )
                appDao.updatePromise(updatedPromise)
            }
        }

        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "REVIEW_SUBMISSION",
                module = "Promise Tracker",
                recordId = submission.id,
                details = "नागरिक प्रमाण समीक्षा: $newStatus | नोट: $notes"
            )
        )
    }


    suspend fun submitComplaint(
        title: String,
        category: String,
        village: String,
        panchayat: String,
        wardArea: String,
        userName: String,
        userMobile: String,
        description: String,
        photoUrl: String = ""
    ): String = withContext(Dispatchers.IO) {
        val count = complaints.first().size + 1
        val newId = "JHL-198-2026-${String.format("%03d", count)}"
        val initialTimeline = """[{"status":"प्राप्त","date":"10 अगस्त 2026","remark":"टीम गोपालसिंह जनसेवा केंद्र में शिकायत दर्ज गई है।"}]"""
        
        val newComplaint = ComplaintEntity(
            id = newId,
            title = title,
            category = category,
            village = village,
            panchayat = panchayat,
            wardArea = wardArea,
            userName = userName,
            userMobile = userMobile,
            description = description,
            status = "प्राप्त",
            timelineStepsJson = initialTimeline,
            photoUrl = photoUrl,
            createdAt = System.currentTimeMillis()
        )
        appDao.insertComplaint(newComplaint)
        newId
    }

    suspend fun escalateComplaintToDepartment(
        complaintId: String,
        department: String,
        dispatchRef: String,
        adminUser: String
    ) = withContext(Dispatchers.IO) {
        val existing = appDao.getComplaintById(complaintId) ?: return@withContext
        val updatedTimeline = """
            [
              {"status":"प्राप्त","date":"10 अगस्त 2026","remark":"शिकायत प्राप्त हुई"},
              {"status":"जांच में","date":"10 अगस्त 2026","remark":"समीक्षा की गई"},
              {"status":"संबंधित विभाग को भेजी गई","date":"10 अगस्त 2026","remark":"$department को डिस्पैच संख्या $dispatchRef प्रेषित (CM Helpline 181 लिंक किया गया)"}
            ]
        """.trimIndent()
        
        val updated = existing.copy(
            status = "संबंधित विभाग को भेजी गई",
            isEscalated = true,
            escalationDepartment = department,
            dispatchReferenceNumber = dispatchRef,
            timelineStepsJson = updatedTimeline,
            updatedAt = System.currentTimeMillis()
        )
        appDao.updateComplaint(updated)
        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "ESCALATE_COMPLAINT",
                module = "Complaints",
                recordId = complaintId,
                details = "शिकायत को $department (प्रेषण $dispatchRef) पर प्रेषित किया गया"
            )
        )
    }

    suspend fun updateComplaintStatus(
        complaintId: String,
        newStatus: String,
        adminUser: String,
        remark: String
    ) = withContext(Dispatchers.IO) {
        val existing = appDao.getComplaintById(complaintId) ?: return@withContext
        val updated = existing.copy(
            status = newStatus,
            updatedAt = System.currentTimeMillis()
        )
        appDao.updateComplaint(updated)
        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "UPDATE_STATUS",
                module = "Complaints",
                recordId = complaintId,
                details = "स्थिति बदलकर '$newStatus' की गई: $remark"
            )
        )
    }

    suspend fun createSocialPost(post: SocialPostEntity, adminUser: String) = withContext(Dispatchers.IO) {
        appDao.insertSocialPost(post)
        appDao.insertAuditLog(
            AuditLogEntity(
                adminUser = adminUser,
                action = "CREATE_SOCIAL_POST",
                module = "Social Studio",
                recordId = post.id,
                details = "नवीन सोशल मीडिया पोस्ट बनाई गई (${post.postType}): ${post.title}"
            )
        )
    }

    suspend fun addSocialLink(link: SocialLinkEntity) = withContext(Dispatchers.IO) {
        appDao.insertSocialLink(link)
    }

    suspend fun addTeamMember(member: TeamMemberEntity) = withContext(Dispatchers.IO) {
        appDao.insertTeamMember(member)
    }

    suspend fun addPublicContact(contact: PublicContactEntity) = withContext(Dispatchers.IO) {
        appDao.insertPublicContact(contact)
    }

    suspend fun addDevelopmentProject(project: DevelopmentProjectEntity) = withContext(Dispatchers.IO) {
        appDao.insertDevelopmentProject(project)
    }

    suspend fun addNewsItem(news: NewsEntity) = withContext(Dispatchers.IO) {
        appDao.insertNewsItem(news)
    }

    suspend fun askAi(query: String): String = withContext(Dispatchers.IO) {
        aiService.answerQuestionWithGrounding(
            userQuery = query,
            villages = villages.first(),
            projects = developmentProjects.first(),
            schemes = govtSchemes.first(),
            schools = schools.first(),
            healthCentres = healthCentres.first()
        )
    }

    suspend fun generateAiSocialContent(category: String, personName: String, details: String): Triple<String, String, String> {
        return aiService.generateSocialPostContent(category, personName, details)
    }
}
