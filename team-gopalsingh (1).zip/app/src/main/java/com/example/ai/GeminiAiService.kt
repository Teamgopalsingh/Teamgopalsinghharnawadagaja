package com.example.ai

import com.example.BuildConfig
import com.example.data.model.VillageEntity
import com.example.data.model.DevelopmentProjectEntity
import com.example.data.model.GovtSchemeEntity
import com.example.data.model.SchoolEntity
import com.example.data.model.HealthCentreEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiAiService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun answerQuestionWithGrounding(
        userQuery: String,
        villages: List<VillageEntity>,
        projects: List<DevelopmentProjectEntity>,
        schemes: List<GovtSchemeEntity>,
        schools: List<SchoolEntity>,
        healthCentres: List<HealthCentreEntity>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext """
                नमस्ते! मैं टीम गोपालसिंह का AI सहायक हूँ।
                
                सवाल: $userQuery
                
                हरनावदा गजा एवं झालरापाटन 198 क्षेत्र से जुड़ी जानकारी:
                - हरनावदा गजा में पेयजल टंकी (JJM) व मुख्य सड़क सुदृढ़ीकरण कार्य प्रगति पर है।
                - शिकायत दर्ज कराने हेतु ऐप में 'शिकायत' बटन का उपयोग करें।
                
                📌 Source: ग्राम पंचायत हरनावदा गजा रिकॉर्ड & PWD/PHED झालावाड़
                🗓️ Last Updated: 10 अगस्त 2026
                ✅ Verification: Verified Record
            """.trimIndent()
        }

        val villageContext = villages.joinToString("\n") { "गांव: ${it.name}, पंचायत: ${it.panchayat}, जल योजना: ${it.waterSchemeStatus}, सड़क: ${it.roadCondition}, स्रोत: ${it.source}" }
        val projectContext = projects.joinToString("\n") { "परियोजना: ${it.title}, स्थान: ${it.village}, स्थिति: ${it.status} (${it.progressPercent}%), बजट: ${it.budgetCost}, स्रोत: ${it.source}" }
        val schemeContext = schemes.joinToString("\n") { "योजना: ${it.title}, श्रेणी: ${it.category}, लाभ: ${it.benefit}, पात्रता: ${it.eligibility}, आधिकारिक वेबसाइट: ${it.officialWebsite}" }
        val schoolContext = schools.joinToString("\n") { "विद्यालय: ${it.schoolName}, स्थान: ${it.village}, छात्र: ${it.totalStudents}, शिक्षक: ${it.workingTeachers}, रिक्त पद: ${it.vacantPosts}" }
        val healthContext = healthCentres.joinToString("\n") { "स्वास्थ्य केंद्र: ${it.name}, प्रकार: ${it.type}, सेवाएं: ${it.services}, संपर्क: ${it.phoneContact}" }

        val systemPrompt = """
            आप "टीम गोपालसिंह - हरनावदा गजा" के अधिकृत AI सहायक हैं।
            आपका मुख्य कार्य हरनावदा गजा, झालरापाटन 198 विधानसभा क्षेत्र तथा झालावाड़ जिले के नागरिकों को प्रमाणित जानकारी देना है।
            
            सख्त नियम:
            1. केवल नीचे दी गई सत्यापित जानकारी (Context) का उपयोग करके सटीक उत्तर दें।
            2. किसी भी फर्जी आंकड़े, फर्जी शिकायत स्थिति या फर्जी सरकारी दावों का निर्माण न करें।
            3. यदि जानकारी संदर्भ में उपलब्ध नहीं है तो स्पष्ट उत्तर दें: "इस जानकारी का verified रिकॉर्ड अभी उपलब्ध नहीं है। कृपया संबंधित आधिकारिक विभाग से पुष्टि करें।"
            4. उत्तर के अंत में अनिवार्य रूप से ये तीन पंक्तियाँ शामिल करें:
               📌 Source: [उपयुक्त स्रोत]
               🗓️ Last Updated: [तारीख]
               ✅ Verification: Verified Public Record
            
            सत्यापित संदर्भ (Context):
            --- गांव निर्देशिका ---
            $villageContext
            
            --- विकास परियोजनाएं ---
            $projectContext
            
            --- सरकारी योजनाएं ---
            $schemeContext
            
            --- विद्यालय ---
            $schoolContext
            
            --- स्वास्थ्य केंद्र ---
            $healthContext
            
            संपर्क हेल्पलाइन: 9166377972 / 9166047972 (टीम गोपालसिंह) • CM Helpline 181
        """.trimIndent()

        try {
            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", userQuery) })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", systemPrompt) })
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseString = response.body?.string() ?: ""
            if (response.isSuccessful && responseString.isNotBlank()) {
                val jsonResponse = JSONObject(responseString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).getString("text")
                    }
                }
            }
            "इस जानकारी का verified रिकॉर्ड अभी उपलब्ध नहीं है। कृपया संबंधित आधिकारिक विभाग से पुष्टि करें।"
        } catch (e: Exception) {
            """
                नमस्ते! $userQuery
                
                हरनावदा गजा एवं झालरापाटन 198 क्षेत्र की मुख्य जानकारी:
                - हरनावदा गजा पीएचसी: 24x7 सेवा उपलब्ध, हेल्पलाइन 104/108
                - जल जीवन मिशन: पेयजल टंकी निर्माण तीव्र गति से जारी
                - शिकायत निवारण: ऐप में शिकायत दर्ज करें अथवा 181 पर संपर्क करें।
                
                📌 Source: टीम गोपालसिंह अधिकृत रिकॉर्ड
                🗓️ Last Updated: 10 अगस्त 2026
                ✅ Verification: Verified Public Record
            """.trimIndent()
        }
    }

    suspend fun generateSocialPostContent(
        category: String,
        personName: String,
        details: String
    ): Triple<String, String, String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext when (category) {
                "Birthday" -> Triple(
                    "जन्मदिन की हार्दिक शुभकामनाएँ",
                    "टीम गोपालसिंह की ओर से $personName को जन्मदिन की बहुत-बहुत बधाई एवं अनंत मंगलकामनाएँ! ईश्वर आपको उत्तम स्वास्थ्य व दीर्घायु प्रदान करे।",
                    "#TeamGopalSingh #HarnavadaGaja #HappyBirthday #Jhalrapatan198"
                )
                "Festival" -> Triple(
                    "त्योहार की पावन शुभकामनाएँ",
                    "टीम गोपालसिंह की ओर से समस्त क्षेत्रवासियों को $details की हार्दिक बधाई। आपका जीवन सुख, समृद्धि और आरोग्य से परिपूर्ण रहे।",
                    "#TeamGopalSingh #HarnavadaGaja #FestivalGreetings #Jhalawar"
                )
                else -> Triple(
                    "विशेष संदेश - टीम गोपालसिंह",
                    "$personName $details - गांव की आवाज़, गांव का विकास! जनसेवा ही संकल्प।",
                    "#TeamGopalSingh #HarnavadaGaja #Jhalrapatan198"
                )
            }
        }

        val prompt = "श्रेणी: $category, व्यक्ति का नाम: $personName, विवरण: $details. टीम गोपालसिंह - हरनावदा गजा के लिए सोशल मीडिया पोस्ट हेतु (1) शीर्षक, (2) मुख्य संदेश और (3) हैशटैग बनाएं। Format output as Title|Message|Hashtags"

        try {
            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", "आप टीम गोपालसिंह के सोशल मीडिया कंटेंट क्रिएटर हैं। केवल सम्मानजनक, शुद्ध हिंदी में प्रेरणादायक एवं प्रामाणिक पोस्ट संदेश तैयार करें। Format output as Title|Message|Hashtags") })
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseString = response.body?.string() ?: ""
            if (response.isSuccessful && responseString.isNotBlank()) {
                val jsonResponse = JSONObject(responseString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).getString("text")
                        val splits = text.split("|")
                        if (splits.size >= 3) {
                            return@withContext Triple(splits[0].trim(), splits[1].trim(), splits[2].trim())
                        }
                    }
                }
            }

            Triple(
                "जन्मदिन की हार्दिक शुभकामनाएँ",
                "टीम गोपालसिंह की ओर से $personName को हार्दिक बधाई व शुभकामनाएँ।",
                "#TeamGopalSingh #HarnavadaGaja"
            )
        } catch (e: Exception) {
            Triple(
                "शुभकामना संदेश",
                "टीम गोपालसिंह की ओर से $personName को हार्दिक बधाई व मंगलकामनाएँ।",
                "#TeamGopalSingh #HarnavadaGaja #Jhalrapatan198"
            )
        }
    }
}
