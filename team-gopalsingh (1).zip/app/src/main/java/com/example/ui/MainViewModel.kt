package com.example.ui

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.MainRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

sealed class NavigationScreen(val route: String, val title: String) {
    object Splash : NavigationScreen("splash", "स्प्लैश")
    object Onboarding : NavigationScreen("onboarding", "मार्गदर्शिका")
    object Home : NavigationScreen("home", "होम")
    object Assembly198 : NavigationScreen("assembly198", "विधानसभा 198")
    object VillageDirectory : NavigationScreen("village_dir", "गांव निर्देशिका")
    object VillageDetail : NavigationScreen("village_detail/{villageId}", "गांव विवरण")
    object AiAssistant : NavigationScreen("ai_assistant", "AI सहायक")
    object Complaints : NavigationScreen("complaints", "जनसमस्या एवं शिकायत")
    object DevelopmentTracker : NavigationScreen("development", "विकास कार्य")
    object EducationHealth : NavigationScreen("edu_health", "शिक्षा एवं स्वास्थ्य")
    object GovtSchemes : NavigationScreen("schemes", "सरकारी योजनाएं")
    object ContactsDirectory : NavigationScreen("contacts", "सार्वजनिक संपर्क एवं कानूनी अधिकार")
    object News : NavigationScreen("news", "समाचार एवं अपडेट")
    object SocialStudio : NavigationScreen("social_studio", "सोशल मीडिया स्टूडियो")
    object Team : NavigationScreen("team", "हमारी टीम")
    object DigitalIdCard : NavigationScreen("digital_id/{memberId}", "डिजिटल टीम आईडी")
    object AdminDashboard : NavigationScreen("admin", "एडमिन पैनल")
    object ProfileSettings : NavigationScreen("profile", "प्रोफाइल एवं सेटिंग्स")
    object GlobalSearch : NavigationScreen("global_search", "खोजें")
    object PromiseTracker : NavigationScreen("promise_tracker", "जनता से किए गए वादे")
    object PromiseDetail : NavigationScreen("promise_detail/{promiseId}", "वादा विवरण")
}

data class ChatMessage(
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class MainViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val db = AppDatabase.getDatabase(application)
    private val repository = MainRepository(db.appDao())

    val villages = repository.villages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val developmentProjects = repository.developmentProjects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val schools = repository.schools.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val healthCentres = repository.healthCentres.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val govtSchemes = repository.govtSchemes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val publicContacts = repository.publicContacts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val newsArticles = repository.newsArticles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val teamMembers = repository.teamMembers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val socialPosts = repository.socialPosts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val complaints = repository.complaints.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditLogs = repository.auditLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val legalInfos = repository.legalInfos.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val socialLinks = repository.socialLinks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val promises = repository.promises.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val promiseSubmissions = repository.promiseSubmissions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // Chat Messages State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "AI",
                text = "राम-राम सा! मैं टीम गोपालसिंह का अधिकृत AI सहायक हूँ। पूछिए, आपको हरनावदा गजा, झालरापाटन 198 या झालावाड़ की सरकारी योजनाओं व विकास कार्यों के बारे में क्या जानना है?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Saved/Favorite IDs
    private val _savedItemIds = MutableStateFlow<Set<String>>(setOf("v001", "sc001"))
    val savedItemIds: StateFlow<Set<String>> = _savedItemIds.asStateFlow()

    // Current Admin Role State
    private val _adminRole = MutableStateFlow<String?>("SUPER ADMIN") // Default for testing full capabilities
    val adminRole: StateFlow<String?> = _adminRole.asStateFlow()

    // User Session Info
    val userName = MutableStateFlow("हरनावदा गजा निवासी")
    val userMobile = MutableStateFlow("9166377972")
    val userVillage = MutableStateFlow("हरनावदा गजा")

    // TextToSpeech Engine
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    init {
        tts = TextToSpeech(application, this)
        viewModelScope.launch {
            repository.seedInitialDataIfNecessary()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
            }
        }
    }

    fun speakHindi(text: String) {
        if (isTtsReady) {
            val cleanedText = text.replace("📌", "").replace("🗓️", "").replace("✅", "")
            tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, null, "AI_TTS")
        }
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun toggleFavorite(id: String) {
        val current = _savedItemIds.value.toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
        } else {
            current.add(id)
        }
        _savedItemIds.value = current
    }

    fun sendAiUserMessage(userQuery: String) {
        if (userQuery.isBlank()) return
        val userMsg = ChatMessage(sender = "USER", text = userQuery)
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiThinking.value = true

        viewModelScope.launch {
            val reply = repository.askAi(userQuery)
            _chatMessages.value = _chatMessages.value + ChatMessage(sender = "AI", text = reply)
            _isAiThinking.value = false
        }
    }

    fun submitComplaint(
        title: String,
        category: String,
        village: String,
        panchayat: String,
        wardArea: String,
        userName: String,
        userMobile: String,
        description: String,
        photoUrl: String = "",
        onComplete: (String) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.submitComplaint(
                title = title,
                category = category,
                village = village,
                panchayat = panchayat,
                wardArea = wardArea,
                userName = userName,
                userMobile = userMobile,
                description = description,
                photoUrl = photoUrl
            )
            onComplete(id)
        }
    }

    fun escalateComplaint(
        complaintId: String,
        department: String,
        dispatchRef: String
    ) {
        viewModelScope.launch {
            repository.escalateComplaintToDepartment(
                complaintId = complaintId,
                department = department,
                dispatchRef = dispatchRef,
                adminUser = _adminRole.value ?: "Admin"
            )
        }
    }

    fun updateComplaintStatus(complaintId: String, status: String, remark: String) {
        viewModelScope.launch {
            repository.updateComplaintStatus(
                complaintId = complaintId,
                newStatus = status,
                adminUser = _adminRole.value ?: "Admin",
                remark = remark
            )
        }
    }

    fun createSocialPost(
        postType: String,
        title: String,
        message: String,
        caption: String,
        personName: String,
        eventDate: String,
        templateId: String,
        hashtags: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val newPost = SocialPostEntity(
                id = "sp_${System.currentTimeMillis()}",
                postType = postType,
                title = title,
                message = message,
                caption = caption,
                personName = personName,
                eventDate = eventDate,
                templateId = templateId,
                hashtags = hashtags,
                status = "Approved",
                scheduledAt = eventDate
            )
            repository.createSocialPost(newPost, _adminRole.value ?: "Admin")
            onSuccess()
        }
    }

    fun generateAiSocialPost(
        category: String,
        personName: String,
        details: String,
        onGenerated: (title: String, message: String, hashtags: String) -> Unit
    ) {
        viewModelScope.launch {
            val (t, m, h) = repository.generateAiSocialContent(category, personName, details)
            onGenerated(t, m, h)
        }
    }

    fun addSocialLink(platform: String, name: String, url: String) {
        viewModelScope.launch {
            repository.addSocialLink(
                SocialLinkEntity(
                    id = "sl_${System.currentTimeMillis()}",
                    platform = platform,
                    name = name,
                    url = url,
                    isActive = true
                )
            )
        }
    }

    fun addTeamMember(name: String, role: String, areaWard: String, phone: String, whatsapp: String) {
        viewModelScope.launch {
            repository.addTeamMember(
                TeamMemberEntity(
                    id = "tm_${System.currentTimeMillis()}",
                    name = name,
                    role = role,
                    areaWard = areaWard,
                    phone = phone,
                    whatsapp = whatsapp,
                    isActive = true,
                    digitalCardCode = "TGS-198-${(100..999).random()}"
                )
            )
        }
    }

    fun addPublicContact(name: String, designation: String, dept: String, office: String, phone: String) {
        viewModelScope.launch {
            repository.addPublicContact(
                PublicContactEntity(
                    id = "pc_${System.currentTimeMillis()}",
                    name = name,
                    designation = designation,
                    department = dept,
                    officeAddress = office,
                    phone = phone
                )
            )
        }
    }

    fun addNews(title: String, category: String, content: String) {
        viewModelScope.launch {
            repository.addNewsItem(
                NewsEntity(
                    id = "nw_${System.currentTimeMillis()}",
                    title = title,
                    category = category,
                    content = content,
                    date = "10 अगस्त 2026"
                )
            )
        }
    }

    // --- Promise Tracker Functions ---
    fun addPromise(
        title: String,
        description: String,
        category: String,
        village: String,
        panchayat: String,
        area: String,
        promiseDate: String,
        promisedBy: String,
        sourceType: String,
        sourceUrl: String,
        status: String,
        promisedWork: String,
        currentStatus: String,
        gapDetails: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val count = (promises.value.size + 1)
            val pId = "PRM-198-${String.format("%03d", count)}"
            val initialTimeline = """[{"stage":"वादा","date":"$promiseDate","proof":"$promisedBy"}]"""
            val newPromise = PromiseEntity(
                id = pId,
                promiseId = pId,
                title = title,
                description = description,
                category = category,
                village = village,
                panchayat = panchayat,
                area = area,
                assembly = "198 - झालरापाटन",
                promiseDate = promiseDate,
                promisedBy = promisedBy,
                sourceType = sourceType,
                sourceUrl = sourceUrl,
                status = status,
                promisedWork = promisedWork,
                currentVerifiedStatus = currentStatus,
                gapDetails = gapDetails,
                timelineJson = initialTimeline,
                lastVerifiedAt = "10 अगस्त 2026"
            )
            repository.addPromise(newPromise, _adminRole.value ?: "Super Admin")
            onSuccess()
        }
    }

    fun updatePromise(promise: PromiseEntity, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.updatePromise(promise, _adminRole.value ?: "Super Admin")
            onSuccess()
        }
    }

    fun deletePromise(promiseId: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.deletePromise(promiseId, _adminRole.value ?: "Super Admin")
            onSuccess()
        }
    }

    fun submitPromiseEvidence(
        promiseId: String,
        promiseTitle: String,
        userName: String,
        userMobile: String,
        village: String,
        submissionType: String,
        infoText: String,
        fileUrl: String,
        onComplete: (String) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.submitPromiseEvidence(
                promiseId = promiseId,
                promiseTitle = promiseTitle,
                userName = userName,
                userMobile = userMobile,
                village = village,
                submissionType = submissionType,
                infoText = infoText,
                fileUrl = fileUrl
            )
            onComplete(id)
        }
    }

    fun reviewPromiseSubmission(
        submission: PromiseSubmissionEntity,
        newStatus: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.reviewPromiseSubmission(
                submission = submission,
                newStatus = newStatus,
                adminUser = _adminRole.value ?: "Super Admin",
                notes = notes
            )
            onSuccess()
        }
    }


    fun setAdminRole(role: String?) {
        _adminRole.value = role
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
