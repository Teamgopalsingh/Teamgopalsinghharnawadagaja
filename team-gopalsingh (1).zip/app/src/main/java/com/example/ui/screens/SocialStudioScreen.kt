package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SocialPostEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun SocialStudioScreen(
    socialPosts: List<SocialPostEntity>,
    onCreatePost: (
        type: String, title: String, message: String, caption: String, personName: String, date: String, templateId: String, hashtags: String, onSuccess: () -> Unit
    ) -> Unit,
    onGenerateAiPost: (category: String, personName: String, details: String, onGenerated: (title: String, message: String, hashtags: String) -> Unit) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    // Form state
    var postType by remember { mutableStateOf("Birthday") }
    var personName by remember { mutableStateOf("रमेश चंद शर्मा") }
    var eventDate by remember { mutableStateOf("10 अगस्त 2026") }
    var customDetails by remember { mutableStateOf("हरनावदा गजा निवासी") }
    var title by remember { mutableStateOf("जन्मदिन की अनंत हार्दिक शुभकामनाएँ") }
    var message by remember { mutableStateOf("टीम गोपालसिंह की ओर से आपको जन्मदिन की बहुत-बहुत बधाई एवं मंगलकामनाएं! ईश्वर आपको दीर्घायु व उत्तम स्वास्थ्य प्रदान करे।") }
    var hashtags by remember { mutableStateOf("#TeamGopalSingh #HarnavadaGaja #HappyBirthday #Jhalrapatan198") }
    var isGeneratingAi by remember { mutableStateOf(false) }

    val postTypes = listOf(
        "Birthday" to "🎂 जन्मदिन",
        "Anniversary" to "💐 वर्षगांठ",
        "Festival" to "🎉 त्योहार",
        "SpecialDay" to "🌟 विशेष दिन",
        "Development" to "🏗️ विकास कार्य",
        "ThankYou" to "🙏 आभार"
    )

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "🎨 सोशल मीडिया पोस्ट स्टूडियो",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "जन्मदिन, त्योहार, विशेष दिन व विकास कार्य पोस्ट जनरेटर",
            fontSize = 12.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = RoyalNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("नया पोस्ट बनाएं", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("स्वीकृत पोस्ट्स (${socialPosts.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(text = "पोस्ट श्रेणी प्रकार चुनें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        postTypes.take(3).forEach { (type, label) ->
                            FilterChip(
                                selected = postType == type,
                                onClick = { postType = type },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        postTypes.drop(3).forEach { (type, label) ->
                            FilterChip(
                                selected = postType == type,
                                onClick = { postType = type },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = personName,
                            onValueChange = { personName = it },
                            label = { Text("व्यक्ति / अवसर का नाम") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = eventDate,
                            onValueChange = { eventDate = it },
                            label = { Text("दिनांक") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = customDetails,
                        onValueChange = { customDetails = it },
                        label = { Text("अतिरिक्त विवरण (जैसे: हरनावदा गजा निवासी / वार्ड सं 4)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // AI Auto Generate Button
                item {
                    Button(
                        onClick = {
                            isGeneratingAi = true
                            onGenerateAiPost(postType, personName, customDetails) { genTitle, genMsg, genHash ->
                                title = genTitle
                                message = genMsg
                                hashtags = genHash
                                isGeneratingAi = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_ai_post_button")
                    ) {
                        if (isGeneratingAi) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI पोस्ट लिख रहा है...", fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SaffronOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("✨ Gemini AI द्वारा स्वतः पोस्ट तैयार करें", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("मुख्य शीर्षक") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("पोस्ट संदेश") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = hashtags,
                        onValueChange = { hashtags = it },
                        label = { Text("हैशटैग") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Post Canvas Card Preview
                item {
                    Text(text = "🎨 पोस्ट कार्ड पूर्वावलोकन (Preview Canvas)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    SocialPostCanvasPreview(
                        postType = postType,
                        personName = personName,
                        title = title,
                        message = message,
                        eventDate = eventDate,
                        hashtags = hashtags
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onCreatePost(
                                    postType, title, message, "$title - $personName", personName, eventDate, "royal_saffron", hashtags
                                ) {
                                    selectedTab = 1
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("सेव करें", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, title)
                                    putExtra(Intent.EXTRA_TEXT, "$title\n\n$message\n\n- टीम गोपालसिंह, हरनावदा गजा • झालरापाटन 198\n\n$hashtags")
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "शेयर करें"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("शेयर करें", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(socialPosts) { post ->
                    SocialPostCanvasPreview(
                        postType = post.postType,
                        personName = post.personName,
                        title = post.title,
                        message = post.message,
                        eventDate = post.eventDate,
                        hashtags = post.hashtags,
                        onShareClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "${post.title}\n\n${post.message}\n\n- टीम गोपालसिंह, हरनावदा गजा\n\n${post.hashtags}")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "शेयर करें"))
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SocialPostCanvasPreview(
    postType: String,
    personName: String,
    title: String,
    message: String,
    eventDate: String,
    hashtags: String,
    onShareClick: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = RoyalNavy),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Badge
            Surface(
                color = SaffronOrange,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "🚩 टीम गोपालसिंह • हरनावदा गजा",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Emblem Avatar
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(3.dp, SaffronOrange, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when(postType) {
                        "Birthday" -> "🎂"
                        "Anniversary" -> "💐"
                        "Festival" -> "🎉"
                        "Development" -> "🏗️"
                        else -> "🚩"
                    },
                    fontSize = 32.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                color = SaffronOrange,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            if (personName.isNotBlank()) {
                Text(
                    text = personName,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = Color.White.copy(alpha = 0.12f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = message,
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🗓️ $eventDate",
                    color = Color.LightGray,
                    fontSize = 10.sp
                )

                Text(
                    text = hashtags,
                    color = SaffronOrange,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (onShareClick != null) {
                Spacer(modifier = Modifier.height(12.dp))
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier
                        .background(SaffronOrange, CircleShape)
                        .size(36.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "शेयर करें", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
