package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SaffronOrange,
    onPrimary = Color.Black,
    primaryContainer = RoyalNavyLight,
    onPrimaryContainer = Color.White,
    secondary = SaffronOrangeLight,
    onSecondary = Color.Black,
    tertiary = GoldenYellow,
    background = DarkBg,
    onBackground = Color.White,
    surface = DarkSurface,
    onSurface = Color.White,
    surfaceVariant = DarkCardBorder,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF334155)
)

private val LightColorScheme = lightColorScheme(
    primary = RoyalNavy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8EEF8),
    onPrimaryContainer = RoyalNavyDark,
    secondary = RoyalGold,
    onSecondary = RoyalNavy,
    secondaryContainer = RoyalGoldLight,
    onSecondaryContainer = RoyalNavyDark,
    tertiary = SaffronOrange,
    background = IvoryBg,
    onBackground = Color(0xFF0C1938),
    surface = Color.White,
    onSurface = Color(0xFF0C1938),
    surfaceVariant = Color(0xFFF7F5EE),
    onSurfaceVariant = Color(0xFF4A5568),
    outline = CardBorderGold
)

@Composable
fun TeamGopalSinghTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep default consistent brand colors
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
