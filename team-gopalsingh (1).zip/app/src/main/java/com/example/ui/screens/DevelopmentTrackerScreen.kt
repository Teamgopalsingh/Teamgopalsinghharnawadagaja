package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DevelopmentProjectEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun DevelopmentTrackerScreen(
    projects: List<DevelopmentProjectEntity>
) {
    var selectedCategory by remember { mutableStateOf("सभी") }
    val categories = listOf("सभी", "सड़क", "पानी", "शिक्षा", "सिंचाई")

    val filtered = if (selectedCategory == "सभी") projects else projects.filter { it.category == selectedCategory }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "🏗️ विकास कार्य एवं परियोजना ट्रैकर",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "हरनावदा गजा • झालरापाटन 198 क्षेत्र",
            fontSize = 12.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 11.sp) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filtered) { project ->
                DevelopmentCardMini(project = project) {}
            }
        }
    }
}
