package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VillageEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun VillageDirectoryScreen(
    villages: List<VillageEntity>,
    onVillageClick: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredVillages = villages.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.panchayat.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "📍 ग्राम व पंचायत निर्देशिका",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "विधानसभा 198 • झालरापाटन, पिड़ावा क्षेत्र",
            fontSize = 12.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("गांव या ग्राम पंचायत खोजें...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "खोजें") },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("village_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredVillages) { village ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onVillageClick(village.id) }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🏡 ${village.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = RoyalNavy
                            )
                            Surface(
                                color = SaffronOrange,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = village.tehsil,
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "पंचायत: ${village.panchayat}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "🏫 स्कूल: ${village.schoolCount}",
                                fontSize = 11.sp,
                                color = RoyalNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "🏥 स्वास्थ्य केंद्र: ${village.healthCentreCount}",
                                fontSize = 11.sp,
                                color = RoyalNavy,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "💧 पेयजल: ${village.waterSchemeStatus}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}
