package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DevelopmentProjectEntity
import com.example.data.model.NewsEntity
import com.example.data.model.PromiseEntity
import com.example.data.model.SocialPostEntity
import com.example.ui.NavigationScreen
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    newsList: List<NewsEntity>,
    projectsList: List<DevelopmentProjectEntity>,
    socialPostsList: List<SocialPostEntity>,
    promisesList: List<PromiseEntity> = emptyList(),
    onNavigate: (NavigationScreen) -> Unit
) {
    val uriHandler = LocalUriHandler.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IvoryBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // 1. App Emblem & Location Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, CardBorderGold),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Emblem
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(RoyalNavy)
                            .border(2.dp, RoyalGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "👑", fontSize = 28.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "टीम गोपालसिंह",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = RoyalNavy
                    )
                    Text(
                        text = "हरनावदा गजा",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SaffronOrange
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    // Tagline
                    Surface(
                        color = RoyalGoldLight,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CardBorderGold)
                    ) {
                        Text(
                            text = "“गांव की आवाज़ • गांव का विकास • गांव के साथ”",
                            color = RoyalNavyDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "📍 ग्राम पंचायत हरनावदा गजा • तहसील पिड़ावा • जिला झालावाड़ (रा०-326034)\n🏛️ विधानसभा क्षेत्र झालरापाटन 198 | 📞 सम्पर्क: 9166377972",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // 2. Welcome Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                border = BorderStroke(1.dp, RoyalGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(RoyalNavyDark, RoyalNavy, RoyalNavyLight)
                            )
                        )
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "झालरापाटन विधानसभा क्षेत्र 198",
                        color = RoyalGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "की जनता के लिए\nएक जनसंपर्क एवं संवाद मंच",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, RoyalGold.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "आपकी बात • आपकी समस्या • आपका सुझाव",
                            color = IvoryBg,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // 3. 8 Royal Main Feature Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "👑 मुख्य सेवाएं व अनुभाग",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = RoyalNavy
                )

                // Row 1: Promises & Development
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RoyalFeatureCard(
                        icon = "🏛️",
                        title = "जनता से किए गए वादे",
                        subtitle = "घोषणाएं व सत्यापन",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.PromiseTracker) }
                    )
                    RoyalFeatureCard(
                        icon = "📋",
                        title = "विकास कार्य",
                        subtitle = "सड़क, पानी, बिजली...",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.DevelopmentTracker) }
                    )
                }

                // Row 2: Janata Voice & Complaints
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RoyalFeatureCard(
                        icon = "🗣️",
                        title = "जनता की आवाज़",
                        subtitle = "मुद्दे व सुझाव दर्ज करें",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.Complaints) }
                    )
                    RoyalFeatureCard(
                        icon = "📝",
                        title = "शिकायत / सुझाव",
                        subtitle = "रेफरेंस नंबर से ट्रैक करें",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.Complaints) }
                    )
                }

                // Row 3: Photo & Video + Village Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RoyalFeatureCard(
                        icon = "📸",
                        title = "फोटो एवं वीडियो",
                        subtitle = "हमारा क्षेत्र - मीडिया",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.SocialStudio) }
                    )
                    RoyalFeatureCard(
                        icon = "📍",
                        title = "गांव की जानकारी",
                        subtitle = "हरनावदा गजा निर्देशिका",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.VillageDirectory) }
                    )
                }

                // Row 4: Important Notice + Contact Us
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RoyalFeatureCard(
                        icon = "📢",
                        title = "महत्वपूर्ण सूचना",
                        subtitle = "सूचनाएं व प्रेस विज्ञप्ति",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.News) }
                    )
                    RoyalFeatureCard(
                        icon = "📞",
                        title = "संपर्क करें",
                        subtitle = "9166377972 | व्हाट्सएप",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavigationScreen.ContactsDirectory) }
                    )
                }
            }
        }

        // 4. Promises Spotlight Section
        item {
            val totalPromises = promisesList.size
            val inProg = promisesList.count { it.status.contains("प्रगति") }
            val completed = promisesList.count { it.status.contains("पूर्ण") }
            val pending = promisesList.count { it.status.contains("घोषित") || it.status.contains("लंबित") }

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                border = BorderStroke(1.dp, RoyalGold),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(NavigationScreen.PromiseTracker) }
                    .testTag("home_promise_tracker_card")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                color = RoyalGold,
                                shape = CircleShape,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = "📜", fontSize = 18.sp)
                                }
                            }
                            Column {
                                Text(
                                    text = "जनता से किए गए वादे",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "सत्यापित घोषणाएं व धरातलीय स्थिति",
                                    color = RoyalGoldLight,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = "खोलें",
                            tint = RoyalGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Counter summary strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                            .padding(vertical = 8.dp, horizontal = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("कुल वादे", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            Text("$totalPromises", color = RoyalGold, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                        Divider(modifier = Modifier.height(20.dp).width(1.dp), color = Color.White.copy(alpha = 0.2f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("प्रगति में", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            Text("$inProg", color = SaffronOrange, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                        Divider(modifier = Modifier.height(20.dp).width(1.dp), color = Color.White.copy(alpha = 0.2f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("पूर्ण", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            Text("$completed", color = Color(0xFF81C784), fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                        Divider(modifier = Modifier.height(20.dp).width(1.dp), color = Color.White.copy(alpha = 0.2f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("घोषित", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            Text("$pending", color = Color(0xFFFFB74D), fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Text(
                        text = "* किसी भी कार्य को बिना सत्यापन 'पूर्ण' नहीं दिखाया गया है।",
                        fontSize = 10.sp,
                        color = Color.LightGray
                    )
                }
            }
        }

        // 5. Development Works Highlights
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(18.dp)
                                .background(RoyalGold, CircleShape)
                        )
                        Text(
                            text = "📋 विकास कार्य रिपोर्ट",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = RoyalNavy
                        )
                    }

                    Text(
                        text = "सभी कार्य →",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalGoldDark,
                        modifier = Modifier.clickable { onNavigate(NavigationScreen.DevelopmentTracker) }
                    )
                }

                projectsList.take(2).forEach { project ->
                    DevelopmentCardMini(project = project) {
                        onNavigate(NavigationScreen.DevelopmentTracker)
                    }
                }
            }
        }

        // 6. Latest Important Notices
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(18.dp)
                                .background(SaffronOrange, CircleShape)
                        )
                        Text(
                            text = "📢 महत्वपूर्ण सूचना",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = RoyalNavy
                        )
                    }

                    Text(
                        text = "सभी सूचनाएं →",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalGoldDark,
                        modifier = Modifier.clickable { onNavigate(NavigationScreen.News) }
                    )
                }

                newsList.take(2).forEach { news ->
                    NewsCardMini(news = news) {
                        onNavigate(NavigationScreen.News)
                    }
                }
            }
        }

        // 7. Contact Card with Direct Call / WhatsApp Buttons
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, CardBorderGold),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📞 संपर्क करें • टीम गोपालसिंह",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = RoyalNavy
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ग्राम पंचायत हरनावदा गजा, तहसील पिड़ावा, जिला झालावाड़, राजस्थान 326034\nविधानसभा क्षेत्र झालरापाटन 198",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                try {
                                    uriHandler.openUri("tel:9166377972")
                                } catch (_: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("📞 कॉल करें", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        Button(
                            onClick = {
                                try {
                                    uriHandler.openUri("https://wa.me/919166377972?text=नमस्ते%20टीम%20गोपालसिंह")
                                } catch (_: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("💬 WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // 8. Footer & Trust / Transparency Disclaimer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "टीम गोपालसिंह • हरनावदा गजा",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = RoyalNavy
                )
                Text(
                    text = "“गांव की आवाज़ • गांव का विकास • गांव के साथ”",
                    fontSize = 11.sp,
                    color = SaffronOrange,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "विधानसभा क्षेत्र झालरापाटन 198 | जनता की भागीदारी • पारदर्शिता • विकास",
                    fontSize = 10.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = Color(0xFFF3F4F6),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFE5E7EB))
                ) {
                    Text(
                        text = "यह ऐप 'टीम गोपालसिंह – हरनावदा गजा' का जनसंपर्क एवं सामुदायिक संवाद मंच है। यह किसी सरकारी विभाग का आधिकारिक ऐप नहीं है।",
                        fontSize = 10.sp,
                        color = Color.DarkGray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(10.dp),
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun RoyalFeatureCard(
    icon: String,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CardBorderGold),
        shadowElevation = 2.dp,
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("royal_card_$title")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(RoyalGoldLight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = icon, fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                color = RoyalNavy,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = Color.Gray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun DevelopmentCardMini(
    project: DevelopmentProjectEntity,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorderGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when(project.status) {
                        "Completed" -> Color(0xFFE8F5E9)
                        "Under Construction" -> Color(0xFFFFF3E0)
                        else -> Color(0xFFE3F2FD)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = when(project.status) {
                            "Completed" -> "🟢 पूर्ण"
                            "Under Construction" -> "🟠 प्रगति पर"
                            else -> "🔵 प्रस्तावित / स्वीकृत"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalNavy,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = project.budgetCost,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = SaffronOrange
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = project.title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = RoyalNavy,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "📍 ${project.village} • ${project.department}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Text(
                    text = "${project.progressPercent}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = RoyalNavy
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { project.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = RoyalGold,
                trackColor = Color(0xFFE2E8F0)
            )
        }
    }
}

@Composable
fun NewsCardMini(
    news: NewsEntity,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorderGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = news.title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = RoyalNavy,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = news.content,
                fontSize = 11.sp,
                color = Color.DarkGray,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "🗓️ ${news.date}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Text(
                    text = news.source,
                    fontSize = 10.sp,
                    color = SaffronOrange,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

