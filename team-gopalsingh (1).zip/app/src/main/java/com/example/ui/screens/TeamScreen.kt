package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TeamMemberEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun TeamScreen(
    teamMembers: List<TeamMemberEntity>,
    onMemberClick: (String) -> Unit
) {
    var selectedCardMember by remember { mutableStateOf<TeamMemberEntity?>(null) }

    if (selectedCardMember != null) {
        AlertDialog(
            onDismissRequest = { selectedCardMember = null },
            title = null,
            text = {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            color = SaffronOrange,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "डिजिटल टीम पहचान पत्र",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(2.dp, SaffronOrange, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "👤", fontSize = 30.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = selectedCardMember?.name ?: "",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = selectedCardMember?.role ?: "",
                            color = SaffronOrange,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            color = Color.White.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = "आईडी कोड: ${selectedCardMember?.digitalCardCode}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(text = "क्षेत्र: ${selectedCardMember?.areaWard}", color = Color.LightGray, fontSize = 11.sp)
                                Text(text = "फोन: ${selectedCardMember?.phone}", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedCardMember = null }) {
                    Text("बंद करें", color = RoyalNavy, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "👥 टीम गोपालसिंह सदस्य",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "हरनावदा गजा • झालरापाटन 198 समर्पित जनसेवक",
            fontSize = 12.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(teamMembers) { member ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedCardMember = member }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(RoyalNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "👤", fontSize = 24.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = member.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = RoyalNavy
                            )
                            Text(
                                text = member.role,
                                fontSize = 12.sp,
                                color = SaffronOrange,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "📍 ${member.areaWard} | 📞 ${member.phone}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        Surface(
                            color = SaffronOrange.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "डिजिटल ID",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SaffronOrange,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
