package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SocialLinkEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun ProfileSettingsScreen(
    userName: String,
    userMobile: String,
    userVillage: String,
    socialLinks: List<SocialLinkEntity>,
    savedCount: Int,
    onAdminClick: () -> Unit
) {
    val context = LocalContext.current
    var showDisclaimerDialog by remember { mutableStateOf(false) }

    if (showDisclaimerDialog) {
        AlertDialog(
            onDismissRequest = { showDisclaimerDialog = false },
            title = { Text("ℹ️ प्लेटफॉर्म डिस्क्लेमर (Disclaimer)", fontWeight = FontWeight.Bold, color = RoyalNavy) },
            text = {
                Text(
                    text = "यह एक स्वतंत्र सामुदायिक सूचना एवं जनसंपर्क प्लेटफॉर्म है। यह भारत सरकार, राजस्थान सरकार, निर्वाचन आयोग या किसी अन्य सरकारी विभाग का आधिकारिक एप्लीकेशन नहीं है।\n\nसमस्त आंकड़े, सरकारी योजनाएं एवं सार्वजनिक रिकॉर्ड जनसूचना पोर्टल व जिला प्रशासन झालावाड़ के सार्वजनिक डोमेन से प्राप्त किए गए हैं।",
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showDisclaimerDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy)
                ) {
                    Text("समझ गया")
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        // Profile Header
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(SaffronOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "👤", fontSize = 28.sp)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userName,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "📍 $userVillage • 📞 $userMobile",
                            color = SaffronOrange,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Saved Items Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = SaffronOrange)
                        Text(
                            text = "मेरी सहेजी गई जानकारी (Favorites)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = RoyalNavy
                        )
                    }

                    Surface(
                        color = RoyalNavy,
                        shape = CircleShape
                    ) {
                        Text(
                            text = "$savedCount",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Official Social Media Channels
        item {
            Text(
                text = "📱 आधिकारिक सोशल मीडिया लिंक्स",
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = RoyalNavy
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                socialLinks.forEach { link ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link.url))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    // Handle browser intent exception
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "🔗 ${link.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalNavy)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SaffronOrange)
                        }
                    }
                }
            }
        }

        // App Information & Admin Panel Entry
        item {
            Text(
                text = "⚙️ ऐप सेटिंग्स व कानूनी डिस्क्लेमर",
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = RoyalNavy
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SettingsTile(
                    title = "🛠️ एडमिन पैनल में प्रवेश करें",
                    onClick = onAdminClick
                )

                SettingsTile(
                    title = "ℹ️ डिस्क्लेमर (Disclaimer)",
                    onClick = { showDisclaimerDialog = true }
                )

                SettingsTile(
                    title = "🔒 गोपनीयता नीति (Privacy Policy)",
                    onClick = { showDisclaimerDialog = true }
                )
            }
        }

        item {
            Text(
                text = "टीम गोपालसिंह – हरनावदा गजा v1.0.0 (Build 2026)",
                fontSize = 11.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun SettingsTile(
    title: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalNavy)
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}
