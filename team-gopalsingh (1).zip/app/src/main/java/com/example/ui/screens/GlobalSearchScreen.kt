package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun GlobalSearchScreen(
    villages: List<VillageEntity>,
    projects: List<DevelopmentProjectEntity>,
    news: List<NewsEntity>,
    schemes: List<GovtSchemeEntity>,
    schools: List<SchoolEntity>,
    onVillageClick: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }

    val matchedVillages = if (query.isBlank()) emptyList() else villages.filter { it.name.contains(query, true) || it.panchayat.contains(query, true) }
    val matchedProjects = if (query.isBlank()) emptyList() else projects.filter { it.title.contains(query, true) || it.village.contains(query, true) }
    val matchedNews = if (query.isBlank()) emptyList() else news.filter { it.title.contains(query, true) || it.content.contains(query, true) }
    val matchedSchemes = if (query.isBlank()) emptyList() else schemes.filter { it.title.contains(query, true) || it.category.contains(query, true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("गांव, योजना, विकास कार्य या समाचार खोजें...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (matchedVillages.isNotEmpty()) {
                item {
                    Text(text = "🏡 गांव (${matchedVillages.size})", fontWeight = FontWeight.Bold, color = RoyalNavy)
                }
                items(matchedVillages) { village ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onVillageClick(village.id) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = village.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = village.panchayat, fontSize = 11.sp, color = SaffronOrange)
                        }
                    }
                }
            }

            if (matchedProjects.isNotEmpty()) {
                item {
                    Text(text = "🏗️ विकास कार्य (${matchedProjects.size})", fontWeight = FontWeight.Bold, color = RoyalNavy)
                }
                items(matchedProjects) { project ->
                    DevelopmentCardMini(project = project) {}
                }
            }

            if (matchedNews.isNotEmpty()) {
                item {
                    Text(text = "📰 समाचार (${matchedNews.size})", fontWeight = FontWeight.Bold, color = RoyalNavy)
                }
                items(matchedNews) { newsItem ->
                    NewsCardMini(news = newsItem) {}
                }
            }
        }
    }
}
