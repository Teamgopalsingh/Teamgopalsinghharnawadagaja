package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DevelopmentProjectEntity
import com.example.data.model.VillageEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun Assembly198Screen(
    villages: List<VillageEntity>,
    projects: List<DevelopmentProjectEntity>,
    onVillageClick: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("परिचय", "ग्राम पंचायतें", "विकास कार्य", "बूथ जानकारी")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {

        // Hero Assembly Banner
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = RoyalNavy),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Surface(
                    color = SaffronOrange,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "विधानसभा क्रमांक – 198 • झालावाड़",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "🏛️ झालरापाटन विधानसभा क्षेत्र",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "“क्षेत्र की जानकारी • जनसमस्याएं • विकास कार्य • जनता की आवाज़”",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Tab Selector
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = RoyalNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Black else FontWeight.Bold
                        )
                    }
                )
            }
        }

        // Tab Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "📍 क्षेत्र परिचय एवं भौगोलिक स्थिति",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = RoyalNavy
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "झालरापाटन विधानसभा क्षेत्र 198 राजस्थान के झालावाड़ जिले का सबसे प्रमुख ऐतिहासिक एवं कृषि बाहुल्य क्षेत्र है। इसमें झालरापाटन नगर पालिका, सुनेल, पिड़ावा उपखंड एवं हरनावदा गजा सहित अनेक ग्राम पंचायतें सम्मिलित हैं।",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 18.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))
                                Divider()
                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = "📊 मुख्य आंकड़े (Verified Data)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = RoyalNavy
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "• जिला: झालावाड़ (राजस्थान)", fontSize = 12.sp)
                                Text(text = "• उपखंड: पिड़ावा एवं झालरापाटन", fontSize = 12.sp)
                                Text(text = "• प्रमुख केंद्र: हरनावदा गजा, सुनेल, पिड़ावा, झालरापाटन", fontSize = 12.sp)
                                Text(text = "• प्रमुख नदियां व सिंचाई: कालीसिंध, आहू व स्थानीय एनिकट", fontSize = 12.sp)
                            }
                        }
                    }
                }

                1 -> {
                    items(villages) { village ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onVillageClick(village.id) }
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "📍 ${village.name}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = RoyalNavy
                                    )
                                    Surface(
                                        color = SaffronOrange.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "Verified",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SaffronOrange,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = village.panchayat,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "• विद्यालय: ${village.schoolCount} | स्वास्थ्य केंद्र: ${village.healthCentreCount}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }

                2 -> {
                    items(projects) { project ->
                        DevelopmentCardMini(project = project) {}
                    }
                }

                3 -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "🗳️ मतदान केंद्र व बूथ निर्देशिका",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = RoyalNavy
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "केवल सार्वजनिक अधिकृत बीएलओ (BLO) व केंद्र स्थान जानकारी:\n• बूथ सं. 101 - राजकीय उच्च माध्यमिक विद्यालय हरनावदा गजा (कमरा नं 1)\n• बूथ सं. 102 - राजकीय उच्च माध्यमिक विद्यालय हरनावदा गजा (कमरा नं 2)\n• बूथ सं. 103 - राजकीय प्राथमिक विद्यालय सुनेल\n\nनोट: गोपनीयता व नियमानुसार व्यक्तिगत मतदाता विवरण संग्रहीत नहीं किया जाता है।",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
