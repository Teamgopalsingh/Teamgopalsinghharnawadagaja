package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PromiseEntity
import com.example.ui.theme.*
import org.json.JSONArray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromiseDetailScreen(
    promise: PromiseEntity?,
    onBackClick: () -> Unit,
    onSubmitEvidence: (promiseId: String, promiseTitle: String, name: String, mobile: String, village: String, type: String, info: String, file: String) -> Unit
) {
    if (promise == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(RoyalNavy),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("वादा रिकॉर्ड नहीं मिला", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onBackClick, colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)) {
                    Text("वापस जाएं", color = Color.White)
                }
            }
        }
        return
    }

    var showEvidenceModal by remember { mutableStateOf(false) }
    val uriHandler = LocalUriHandler.current

    val statusColor = when {
        promise.status.contains("पूर्ण") -> Color(0xFF2E7D32)
        promise.status.contains("प्रगति में") -> Color(0xFFEF6C00)
        promise.status.contains("स्वीकृत") -> Color(0xFF1565C0)
        promise.status.contains("लंबित") -> Color(0xFFD84315)
        promise.status.contains("सत्यापन") -> Color(0xFFC62828)
        else -> Color(0xFF616161)
    }

    // Parse Timeline JSON
    val timelineList = remember(promise.timelineJson) {
        val list = mutableListOf<Pair<String, Pair<String, String>>>()
        try {
            val array = JSONArray(promise.timelineJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val stage = obj.optString("stage", "चरण ${i + 1}")
                val date = obj.optString("date", "—")
                val proof = obj.optString("proof", "")
                list.add(Pair(stage, Pair(date, proof)))
            }
        } catch (e: Exception) {
            list.add(Pair("वादा घोषणा", Pair(promise.promiseDate, promise.promisedBy)))
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("वादा विवरण & ट्रैक रिकॉर्ड", color = GoldenYellow, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("ID: ${promise.promiseId}", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "पीछे", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = RoyalNavy)
            )
        },
        containerColor = RoyalNavy
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            RoyalNavy,
                            RoyalNavy.copy(alpha = 0.95f),
                            Color(0xFF0D1B2A)
                        )
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Top Card Header & Status Badge ---
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = GoldenYellow,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = promise.promiseId,
                                    color = RoyalNavy,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                color = statusColor,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = promise.status,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = promise.title,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 26.sp
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = GoldenYellow, modifier = Modifier.size(16.dp))
                            Text(
                                text = "सत्यापन स्थिति: ${promise.verificationStatus} • अंतिम जाँच: ${promise.lastVerifiedAt}",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // --- Section 1: वादा क्या था? ---
            item {
                DetailSectionCard(title = "📜 Section 1: वादा क्या था?") {
                    DetailRow(label = "श्रेणी", value = promise.category)
                    DetailRow(label = "घोषणा विवरण", value = promise.description)
                    DetailRow(label = "किसके द्वारा किया गया", value = promise.promisedBy)
                    DetailRow(label = "प्रमाण स्रोत प्रकार", value = promise.sourceType)
                    if (promise.sourceUrl.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    try { uriHandler.openUri(promise.sourceUrl) } catch (_: Exception) {}
                                },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("आधिकारिक लिंक / स्रोत URL", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                            Text("लिंक खोलें 🔗", color = GoldenYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // --- Section 2: किस क्षेत्र के लिए? ---
            item {
                DetailSectionCard(title = "📍 Section 2: क्षेत्र जानकारी") {
                    DetailRow(label = "विधानसभा क्षेत्र", value = promise.assembly)
                    DetailRow(label = "तहसील / क्षेत्र", value = promise.area)
                    DetailRow(label = "ग्राम पंचायत", value = promise.panchayat)
                    DetailRow(label = "गांव / शहर", value = promise.village)
                }
            }

            // --- Section 3: तारीख व स्थिति ---
            item {
                DetailSectionCard(title = "📅 Section 3: तारीख व वर्तमान स्थिति") {
                    DetailRow(label = "वादा घोषणा तिथि", value = promise.promiseDate)
                    DetailRow(label = "वर्तमान स्थिति श्रेणी", value = promise.status)
                    DetailRow(label = "अंतिम प्रत्यक्ष सत्यापन", value = promise.lastVerifiedAt)
                }
            }

            // --- Section 4: Timeline ---
            item {
                DetailSectionCard(title = "⏳ Section 4: कार्य प्रगति टाइमलाइन") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        timelineList.forEachIndexed { index, pair ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(28.dp)) {
                                    Surface(
                                        color = if (index == timelineList.size - 1) SaffronOrange else GoldenYellow,
                                        shape = CircleShape,
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("${index + 1}", color = RoyalNavy, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    if (index < timelineList.size - 1) {
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(30.dp)
                                                .background(GoldenYellow.copy(alpha = 0.5f))
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(pair.first, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(pair.second.first, color = GoldenYellow, fontSize = 11.sp)
                                    }
                                    if (pair.second.second.isNotEmpty()) {
                                        Text(
                                            text = "प्रमाण: ${pair.second.second}",
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- Section 5: वादा बनाम वर्तमान स्थिति ---
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaffronOrange.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, SaffronOrange.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "⚖️ Section 5: वादा बनाम वर्तमान स्थिति",
                            color = SaffronOrange,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Divider(color = SaffronOrange.copy(alpha = 0.3f))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("📜 वादा (घोषित कार्य):", color = GoldenYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (promise.promisedWork.isNotEmpty()) promise.promisedWork else promise.description,
                                color = Color.White,
                                fontSize = 13.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text("🔍 वर्तमान स्थिति (सत्यापित धरातल):", color = Color(0xFF64B5F6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (promise.currentVerifiedStatus.isNotEmpty()) promise.currentVerifiedStatus else "सत्यापन प्रक्रियाधीन है।",
                                color = Color.White,
                                fontSize = 13.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text("📊 अंतर विवरण (Action Gap):", color = Color(0xFFFFB74D), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (promise.gapDetails.isNotEmpty()) promise.gapDetails else "घोषणा के अनुरूप प्रगति का विश्लेषण जारी है।",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // --- Section 6: प्रमाण व स्रोत ---
            item {
                DetailSectionCard(title = "📄 Section 6: प्रमाण व दस्तावेज़") {
                    DetailRow(label = "प्रमाण श्रेणी", value = promise.sourceType)
                    DetailRow(label = "एडमिन नोट्स", value = if (promise.adminNotes.isNotEmpty()) promise.adminNotes else "कोई अतिरिक्त टिप्पणी नहीं")
                }
            }

            // --- Section 7: Public Submission Action Card ---
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GoldenYellow.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = GoldenYellow, modifier = Modifier.size(32.dp))
                        Text(
                            text = "क्या आपके पास इस वादे की अतिरिक्त जानकारी है?",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "फोटो/वीडियो/दस्तावेज़/जानकारी भेजकर जनता के रिकॉर्ड को सटीक बनाने में सहयोग करें।",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Button(
                            onClick = { showEvidenceModal = true },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldenYellow),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("submit_evidence_button")
                        ) {
                            Text("📸 फोटो / जानकारी भेजें", color = RoyalNavy, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }

                        Text(
                            text = "नोट: आपके द्वारा भेजी गई जानकारी एडमिन समीक्षा (Verification) के पश्चात ही प्रकाशित होगी।",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }

    if (showEvidenceModal) {
        PublicEvidenceSubmissionDialog(
            promiseId = promise.id,
            promiseTitle = promise.title,
            defaultVillage = promise.village,
            onDismiss = { showEvidenceModal = false },
            onSubmit = { name, mobile, village, type, info, file ->
                onSubmitEvidence(promise.id, promise.title, name, mobile, village, type, info, file)
                showEvidenceModal = false
            }
        )
    }
}

@Composable
private fun DetailSectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.06f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text = title, color = GoldenYellow, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Divider(color = Color.White.copy(alpha = 0.1f))
            content()
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = label, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
        Text(text = value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicEvidenceSubmissionDialog(
    promiseId: String,
    promiseTitle: String,
    defaultVillage: String,
    onDismiss: () -> Unit,
    onSubmit: (name: String, mobile: String, village: String, type: String, info: String, file: String) -> Unit
) {
    var userName by remember { mutableStateOf("") }
    var userMobile by remember { mutableStateOf("") }
    var village by remember { mutableStateOf(defaultVillage) }
    var selectedType by remember { mutableStateOf("📷 फोटो") }
    var infoText by remember { mutableStateOf("") }
    var fileUrl by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val types = listOf("📷 फोटो", "🎥 वीडियो", "📄 दस्तावेज़", "📝 जानकारी")

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    if (userName.isBlank() || userMobile.length < 10 || infoText.isBlank()) {
                        errorMessage = "कृपया अपना नाम, 10 अंकों का मोबाइल नंबर व जानकारी भरें"
                    } else {
                        onSubmit(userName, userMobile, village, selectedType, infoText, fileUrl)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
            ) {
                Text("जमा करें (Submit)", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें", color = Color.White.copy(alpha = 0.7f))
            }
        },
        title = {
            Text("सार्वजनिक प्रमाण व जानकारी भेजें", color = GoldenYellow, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("वादा: $promiseTitle", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, fontWeight = FontWeight.Medium)

                if (errorMessage.isNotEmpty()) {
                    Text(errorMessage, color = Color(0xFFEF5350), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = userName,
                    onValueChange = { userName = it },
                    label = { Text("आपका नाम*", color = Color.White.copy(alpha = 0.7f)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = userMobile,
                    onValueChange = { if (it.length <= 10) userMobile = it },
                    label = { Text("मोबाइल नंबर*", color = Color.White.copy(alpha = 0.7f)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = village,
                    onValueChange = { village = it },
                    label = { Text("गांव / शहर", color = Color.White.copy(alpha = 0.7f)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("प्रमाण का प्रकार:", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    types.forEach { t ->
                        FilterChip(
                            selected = selectedType == t,
                            onClick = { selectedType = t },
                            label = { Text(t, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = infoText,
                    onValueChange = { infoText = it },
                    label = { Text("विस्तृत जानकारी / धरातलीय स्थिति*", color = Color.White.copy(alpha = 0.7f)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = fileUrl,
                    onValueChange = { fileUrl = it },
                    label = { Text("फाइल / गूगल ड्राइव / फोटो लिंक (यदि हो)", color = Color.White.copy(alpha = 0.7f)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        containerColor = RoyalNavy,
        shape = RoundedCornerShape(20.dp)
    )
}
