package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ComplaintEntity
import com.example.ui.theme.*

@Composable
fun ComplaintScreen(
    complaints: List<ComplaintEntity>,
    onSubmitComplaint: (
        title: String,
        category: String,
        village: String,
        panchayat: String,
        ward: String,
        name: String,
        mobile: String,
        desc: String,
        onComplete: (String) -> Unit
    ) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var submittedIdAlert by remember { mutableStateOf<String?>(null) }

    // Form states
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("पानी") }
    var village by remember { mutableStateOf("हरनावदा गजा") }
    var panchayat by remember { mutableStateOf("ग्राम पंचायत हरनावदा गजा") }
    var wardArea by remember { mutableStateOf("वार्ड नं. 3") }
    var userName by remember { mutableStateOf("विक्रम सिंह") }
    var userMobile by remember { mutableStateOf("9166377972") }
    var description by remember { mutableStateOf("") }
    var photoAttached by remember { mutableStateOf(false) }

    val categories = listOf("पानी", "सड़क", "बिजली", "शिक्षा", "स्वास्थ्य", "कृषि व सिंचाई", "अन्य")

    if (submittedIdAlert != null) {
        AlertDialog(
            onDismissRequest = { submittedIdAlert = null },
            title = { Text("✅ शिकायत दर्ज हो गई!", fontWeight = FontWeight.Black, color = RoyalNavy) },
            text = {
                Column {
                    Text("आपकी शिकायत सफलतापूर्व दर्ज कर ली गई है।")
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = RoyalGoldLight,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CardBorderGold)
                    ) {
                        Text(
                            text = "यूनिक शिकायत ID: ${submittedIdAlert}",
                            fontWeight = FontWeight.Black,
                            color = RoyalNavy,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("टीम द्वारा सत्यापन के पश्चात इसे संबंधित विभाग (PWD / PHED / CM Helpline 181) में प्रेषित किया जाएगा।", fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        submittedIdAlert = null
                        selectedTab = 1
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy)
                ) {
                    Text("ट्रैक करें", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            containerColor = IvoryBg,
            shape = RoundedCornerShape(20.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IvoryBg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "🗣️ जनता की आवाज़ • शिकायत एवं सुझाव",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "हरनावदा गजा • विधानसभा झालरापाटन 198",
            fontSize = 11.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = RoyalNavy,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).padding(bottom = 12.dp)
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("नई शिकायत दर्ज करें", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("मेरी शिकायतें (${complaints.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(text = "समस्या की श्रेणी चुनें", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalNavy)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.take(4).forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.drop(4).forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("समस्या का शीर्षक (जैसे: पानी लीकेज / सड़क नाली)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complaint_title_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = village,
                            onValueChange = { village = it },
                            label = { Text("गांव") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = wardArea,
                            onValueChange = { wardArea = it },
                            label = { Text("वार्ड / क्षेत्र") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = userName,
                            onValueChange = { userName = it },
                            label = { Text("आपका नाम") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = userMobile,
                            onValueChange = { userMobile = it },
                            label = { Text("मोबाइल नंबर") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("समस्या का पूरा विवरण लिखें...") },
                        minLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complaint_desc_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    OutlinedButton(
                        onClick = { photoAttached = !photoAttached },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = RoyalNavy)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (photoAttached) "📷 फोटो संलग्न हो गई (✓)" else "📷 फोटो संलग्न करें (वैकल्पिक)",
                            color = RoyalNavy,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                item {
                    Button(
                        onClick = {
                            if (title.isNotBlank() && description.isNotBlank()) {
                                onSubmitComplaint(
                                    title, category, village, panchayat, wardArea, userName, userMobile, description
                                ) { newId ->
                                    submittedIdAlert = newId
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_complaint_button")
                    ) {
                        Text("शिकायत दर्ज करें (Submit)", fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(complaints) { complaint ->
                    ComplaintTimelineCard(complaint = complaint)
                }
            }
        }
    }
}

@Composable
fun ComplaintTimelineCard(complaint: ComplaintEntity) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorderGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = RoyalNavy,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = complaint.id,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Surface(
                    color = when(complaint.status) {
                        "समाधान" -> Color(0xFFDCFCE7)
                        "संबंधित विभाग को भेजी गई" -> Color(0xFFEFF6FF)
                        else -> Color(0xFFFEF3C7)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = complaint.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalNavy,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = complaint.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = RoyalNavy
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = complaint.description,
                fontSize = 12.sp,
                color = Color.DarkGray
            )

            if (complaint.isEscalated) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = RoyalGoldLight),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CardBorderGold)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "🏛️ विभाग प्रेषण (Official Escalation)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = RoyalNavy
                        )
                        Text(
                            text = "विभाग: ${complaint.escalationDepartment}\nडिस्पैच संख्या: ${complaint.dispatchReferenceNumber}",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "👤 ${complaint.userName} (${complaint.wardArea})",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Text(
                    text = "📞 ${complaint.userMobile}",
                    fontSize = 11.sp,
                    color = SaffronOrange,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

