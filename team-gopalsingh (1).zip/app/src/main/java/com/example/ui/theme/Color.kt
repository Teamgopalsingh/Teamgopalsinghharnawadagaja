package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Palette: Team Gopal Singh - Royal Rajasthan & Sun Temple Aesthetic
val RoyalNavy = Color(0xFF0B1B3D)
val RoyalNavyDark = Color(0xFF061027)
val RoyalNavyLight = Color(0xFF162D59)

val RoyalGold = Color(0xFFD4AF37)
val RoyalGoldLight = Color(0xFFF7ECBF)
val RoyalGoldDark = Color(0xFFB8860B)
val CardBorderGold = Color(0xFFE5D29A)

val IvoryBg = Color(0xFFFDFBF7)
val IvorySurface = Color(0xFFFFFFFF)

val SaffronOrange = Color(0xFFE87722)
val SaffronOrangeLight = Color(0xFFFFB366)
val SaffronOrangeDark = Color(0xFFC45A00)

val GoldenYellow = Color(0xFFD4AF37) // Alias for Gold compatibility
val LightBg = Color(0xFFFAF8F5)
val CardBorder = Color(0xFFE2E8F0)

val SuccessGreen = Color(0xFF117A37)
val WarningOrange = Color(0xFFED6C02)
val ErrorRed = Color(0xFFC62828)
val InfoBlue = Color(0xFF0288D1)

// Dark Palette
val DarkBg = Color(0xFF0B1320)
val DarkSurface = Color(0xFF152238)
val DarkCardBorder = Color(0xFF21324E)

