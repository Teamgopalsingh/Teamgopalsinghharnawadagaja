package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun AdminDashboardScreen(
    adminRole: String?,
    complaints: List<ComplaintEntity>,
    socialLinks: List<SocialLinkEntity>,
    auditLogs: List<AuditLogEntity>,
    promises: List<PromiseEntity> = emptyList(),
    promiseSubmissions: List<PromiseSubmissionEntity> = emptyList(),
    onEscalateComplaint: (complaintId: String, department: String, dispatchRef: String) -> Unit,
    onAddSocialLink: (platform: String, name: String, url: String) -> Unit,
    onAddPublicContact: (name: String, designation: String, dept: String, office: String, phone: String) -> Unit,
    onAddNews: (title: String, category: String, content: String) -> Unit,
    onAddPromise: (
        title: String, description: String, category: String, village: String, panchayat: String, area: String,
        promiseDate: String, promisedBy: String, sourceType: String, sourceUrl: String, status: String,
        promisedWork: String, currentStatus: String, gapDetails: String
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _, _, _, _, _ -> },
    onReviewPromiseSubmission: (submission: PromiseSubmissionEntity, newStatus: String, notes: String) -> Unit = { _, _, _ -> }
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    // Add Promise Dialog State
    var showAddPromiseDialog by remember { mutableStateOf(false) }
    var pTitle by remember { mutableStateOf("") }
    var pDesc by remember { mutableStateOf("") }
    var pCategory by remember { mutableStateOf("सड़क") }
    var pVillage by remember { mutableStateOf("हरनावदा गजा") }
    var pPanchayat by remember { mutableStateOf("ग्राम पंचायत हरनावदा गजा") }
    var pArea by remember { mutableStateOf("पिड़ावा / झालरापाटन") }
    var pDate by remember { mutableStateOf("10 अगस्त 2026") }
    var pBy by remember { mutableStateOf("सार्वजनिक घोषणा") }
    var pSourceType by remember { mutableStateOf("आधिकारिक दस्तावेज़") }
    var pSourceUrl by remember { mutableStateOf("") }
    var pStatus by remember { mutableStateOf("लंबित") }
    var pPromisedWork by remember { mutableStateOf("") }
    var pCurrentStatus by remember { mutableStateOf("") }
    var pGapDetails by remember { mutableStateOf("") }


    // Escalation Dialog State
    var selectedComplaintToEscalate by remember { mutableStateOf<ComplaintEntity?>(null) }
    var escDept by remember { mutableStateOf("PHED पिड़ावा (पानी विभाग)") }
    var escDispatchRef by remember { mutableStateOf("TGS/JHL/2026/${(100..999).random()}") }

    // Social Link Dialog State
    var showAddLinkDialog by remember { mutableStateOf(false) }
    var linkPlatform by remember { mutableStateOf("Facebook") }
    var linkName by remember { mutableStateOf("टीम गोपालसिंह अधिकृत पेज") }
    var linkUrl by remember { mutableStateOf("https://facebook.com/teamgopalsingh") }

    // Add News State
    var showAddNewsDialog by remember { mutableStateOf(false) }
    var newsTitle by remember { mutableStateOf("") }
    var newsCat by remember { mutableStateOf("विकास") }
    var newsContent by remember { mutableStateOf("") }

    if (selectedComplaintToEscalate != null) {
        AlertDialog(
            onDismissRequest = { selectedComplaintToEscalate = null },
            title = { Text("🏛️ शिकायत को विभाग में प्रेषित करें", fontWeight = FontWeight.Bold, color = RoyalNavy) },
            text = {
                Column {
                    Text("शिकायत ID: ${selectedComplaintToEscalate?.id}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = escDept,
                        onValueChange = { escDept = it },
                        label = { Text("संबंधित विभाग (जैसे: PWD / PHED / CM Helpline 181)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = escDispatchRef,
                        onValueChange = { escDispatchRef = it },
                        label = { Text("आधिकारिक प्रेषण संख्या (Dispatch Reference #)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedComplaintToEscalate?.let {
                            onEscalateComplaint(it.id, escDept, escDispatchRef)
                        }
                        selectedComplaintToEscalate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
                ) {
                    Text("विभाग को प्रेषित करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedComplaintToEscalate = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    if (showAddLinkDialog) {
        AlertDialog(
            onDismissRequest = { showAddLinkDialog = false },
            title = { Text("🔗 सोशल मीडिया ID जोड़ें", fontWeight = FontWeight.Bold, color = RoyalNavy) },
            text = {
                Column {
                    OutlinedTextField(
                        value = linkPlatform,
                        onValueChange = { linkPlatform = it },
                        label = { Text("प्लेटफॉर्म (Facebook / Instagram / YouTube / WhatsApp)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = linkName,
                        onValueChange = { linkName = it },
                        label = { Text("पेज / ग्रुप नाम") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = linkUrl,
                        onValueChange = { linkUrl = it },
                        label = { Text("प्रोफाइल/ग्रुप URL") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (linkUrl.isNotBlank()) {
                            onAddSocialLink(linkPlatform, linkName, linkUrl)
                        }
                        showAddLinkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy)
                ) {
                    Text("सेव करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddLinkDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    if (showAddNewsDialog) {
        AlertDialog(
            onDismissRequest = { showAddNewsDialog = false },
            title = { Text("📰 नवीन विज्ञप्ति जारी करें", fontWeight = FontWeight.Bold, color = RoyalNavy) },
            text = {
                Column {
                    OutlinedTextField(
                        value = newsTitle,
                        onValueChange = { newsTitle = it },
                        label = { Text("शीर्षक") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newsContent,
                        onValueChange = { newsContent = it },
                        label = { Text("विज्ञप्ति विवरण") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newsTitle.isNotBlank()) {
                            onAddNews(newsTitle, newsCat, newsContent)
                        }
                        showAddNewsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
                ) {
                    Text("जारी करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNewsDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Admin Header Banner
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = RoyalNavy),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "🛠️ टीम गोपालसिंह एडमिन पैनल",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "भूमिका: ${adminRole ?: "SUPER ADMIN"}",
                        color = SaffronOrange,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    color = SaffronOrange,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Verified Admin",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = RoyalNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("शिकायतें", fontSize = 10.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("वादे", fontSize = 10.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("नागरिक प्रमाण", fontSize = 10.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("सोशल ID", fontSize = 10.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("कंटेंट", fontSize = 10.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 5, onClick = { selectedTab = 5 }, text = { Text("ऑडिट", fontSize = 10.sp, fontWeight = FontWeight.Bold) })
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    items(complaints) { complaint ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "ID: ${complaint.id}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalNavy)
                                    Text(text = complaint.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SaffronOrange)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = complaint.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = "गांव: ${complaint.village} • आवेदक: ${complaint.userName} (${complaint.userMobile})", fontSize = 11.sp, color = Color.Gray)

                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { selectedComplaintToEscalate = complaint },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalNavy),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("🏛️ विभाग में प्रेषित करें (Escalate)", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Tab 1: Promise Management
                1 -> {
                    item {
                        Button(
                            onClick = { showAddPromiseDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_add_promise_btn")
                        ) {
                            Text("➕ नया सार्वजनिक वादा/घोषणा दर्ज करें", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    items(promises) { p ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("ID: ${p.promiseId}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalNavy)
                                    Surface(
                                        color = SaffronOrange,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(p.status, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Text(p.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("गांव: ${p.village} (${p.panchayat}) • श्रेणी: ${p.category}", fontSize = 11.sp, color = Color.DarkGray)
                                Text("घोषणा तिथि: ${p.promiseDate} | स्रोत: ${p.sourceType}", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }
                }

                // Tab 2: Promise Evidence Submissions
                2 -> {
                    if (promiseSubmissions.isEmpty()) {
                        item {
                            Text("कोई समीक्षा हेतु लंबित प्रमाण नहीं है।", modifier = Modifier.padding(16.dp), color = Color.Gray)
                        }
                    } else {
                        items(promiseSubmissions) { sub ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("प्रमाण ID: ${sub.id}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalNavy)
                                        Text(sub.status, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (sub.status == "Approved") Color(0xFF2E7D32) else SaffronOrange)
                                    }
                                    Text("वादा: ${sub.promiseTitle}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("नागरिक: ${sub.userName} (${sub.userMobile}) • गांव: ${sub.village}", fontSize = 11.sp, color = Color.DarkGray)
                                    Text("प्रकार: ${sub.submissionType}", fontSize = 11.sp, color = RoyalNavy, fontWeight = FontWeight.Bold)
                                    Text("विवरण: ${sub.infoText}", fontSize = 12.sp)

                                    if (sub.status == "Pending Verification") {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = {
                                                    onReviewPromiseSubmission(sub, "Approved", "एडमिन द्वारा सत्यापित एवं अनुमोदित")
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("स्वीकार करें (Approve)", fontSize = 11.sp)
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    onReviewPromiseSubmission(sub, "Rejected", "अपूर्ण या असत्यापित जानकारी")
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("अस्वीकार करें", fontSize = 11.sp, color = Color.Red)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                3 -> {
                    item {
                        Button(
                            onClick = { showAddLinkDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_social_link_button")
                        ) {
                            Text("➕ नई सोशल मीडिया ID / ग्रुप जोड़ें", fontWeight = FontWeight.Bold)
                        }
                    }

                    items(socialLinks) { link ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = "${link.platform}: ${link.name}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = RoyalNavy)
                                    Text(text = link.url, fontSize = 11.sp, color = Color.Gray)
                                }
                                Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(6.dp)) {
                                    Text("सक्रिय", fontSize = 10.sp, color = RoyalNavy, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }
                    }
                }

                4 -> {
                    item {
                        Button(
                            onClick = { showAddNewsDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("➕ नई प्रेस विज्ञप्ति जारी करें", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                5 -> {
                    items(auditLogs) { log ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "👤 ${log.adminUser} • ${log.action}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalNavy)
                                    Text(text = log.timestamp, fontSize = 10.sp, color = Color.Gray)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = log.details, fontSize = 11.sp, color = Color.DarkGray)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddPromiseDialog) {
        AlertDialog(
            onDismissRequest = { showAddPromiseDialog = false },
            title = { Text("➕ नया वादा/घोषणा रिकॉर्ड जोड़ें", fontWeight = FontWeight.Bold, color = RoyalNavy) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.heightIn(max = 350.dp)
                ) {
                    OutlinedTextField(
                        value = pTitle,
                        onValueChange = { pTitle = it },
                        label = { Text("वादा शीर्षक*") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = pDesc,
                        onValueChange = { pDesc = it },
                        label = { Text("विवरण*") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = pVillage,
                        onValueChange = { pVillage = it },
                        label = { Text("गांव/शहर*") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = pPanchayat,
                        onValueChange = { pPanchayat = it },
                        label = { Text("ग्राम पंचायत*") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pTitle.isNotBlank() && pVillage.isNotBlank()) {
                            onAddPromise(
                                pTitle, pDesc, pCategory, pVillage, pPanchayat, pArea,
                                pDate, pBy, pSourceType, pSourceUrl, pStatus,
                                pPromisedWork, pCurrentStatus, pGapDetails
                            )
                        }
                        showAddPromiseDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
                ) {
                    Text("सेव करें", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPromiseDialog = false }) { Text("रद्द करें") }
            }
        )
    }
}

