package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DevelopmentProjectEntity
import com.example.data.model.SchoolEntity
import com.example.data.model.VillageEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun VillageDetailScreen(
    village: VillageEntity?,
    projects: List<DevelopmentProjectEntity>,
    schools: List<SchoolEntity>
) {
    if (village == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("गांव विवरण उपलब्ध नहीं है।")
        }
        return
    }

    val villageProjects = projects.filter { it.village == village.name }
    val villageSchools = schools.filter { it.village == village.name }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "🏡 ${village.name}",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "${village.panchayat} • ${village.tehsil}",
                        color = SaffronOrange,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = village.description,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "📌 स्रोत: ${village.source} | 🗓️ ${village.lastUpdated}",
                            fontSize = 10.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "💧 पेयजल व बुनियादी ढांचा",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = RoyalNavy
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "• पेयजल योजना: ${village.waterSchemeStatus}", fontSize = 12.sp)
                    Text(text = "• सड़क स्थिति: ${village.roadCondition}", fontSize = 12.sp)
                    Text(text = "• प्राथमिक स्वास्थ्य केंद्र: ${village.healthCentreCount} इकाई", fontSize = 12.sp)
                }
            }
        }

        item {
            Text(
                text = "🏗️ गांव में स्वीकृत व चालू विकास कार्य (${villageProjects.size})",
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = RoyalNavy
            )
        }

        items(villageProjects) { project ->
            DevelopmentCardMini(project = project) {}
        }

        item {
            Text(
                text = "🏫 गांव में विद्यालय (${villageSchools.size})",
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = RoyalNavy
            )
        }

        items(villageSchools) { school ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = school.schoolName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = RoyalNavy
                    )
                    Text(
                        text = "${school.category} • छात्र: ${school.totalStudents} | कार्यरत शिक्षक: ${school.workingTeachers}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "सुविधाएं: ${school.facilities}",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
