package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GovtSchemeEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun GovtSchemesScreen(
    schemes: List<GovtSchemeEntity>
) {
    var selectedCat by remember { mutableStateOf("सभी") }
    val categories = listOf("सभी", "किसान", "स्वास्थ्य", "आवास", "पेंशन")

    val filtered = if (selectedCat == "सभी") schemes else schemes.filter { it.category == selectedCat }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "📋 प्रमुख सरकारी योजनाएं",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "राजस्थान व केंद्र सरकार जनकल्याणकारी योजनाएं",
            fontSize = 12.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCat == cat,
                    onClick = { selectedCat = cat },
                    label = { Text(cat, fontSize = 11.sp) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filtered) { scheme ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Surface(
                            color = SaffronOrange,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = scheme.category,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = scheme.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = RoyalNavy
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "🎁 लाभ: ${scheme.benefit}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = RoyalNavy
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "👤 पात्रता: ${scheme.eligibility}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "📄 आवश्यक दस्तावेज: ${scheme.documentsRequired}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "🌐 वेबसाइट: ${scheme.officialWebsite}",
                            fontSize = 11.sp,
                            color = SaffronOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
