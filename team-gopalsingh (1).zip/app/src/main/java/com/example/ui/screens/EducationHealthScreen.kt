package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HealthCentreEntity
import com.example.data.model.SchoolEntity
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun EducationHealthScreen(
    schools: List<SchoolEntity>,
    healthCentres: List<HealthCentreEntity>
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "🏫 शिक्षा एवं 🏥 स्वास्थ्य सेवाएं",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = RoyalNavy
        )
        Text(
            text = "हरनावदा गजा • झालरापाटन 198 अधिकृत रिकॉर्ड",
            fontSize = 12.sp,
            color = SaffronOrange,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = RoyalNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("🏫 विद्यालय (${schools.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("🏥 स्वास्थ्य केंद्र (${healthCentres.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (selectedTab == 0) {
                items(schools) { school ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = school.schoolName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = RoyalNavy
                            )
                            Text(
                                text = "स्थान: ${school.village} (${school.category})",
                                fontSize = 12.sp,
                                color = SaffronOrange,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text(text = "👨‍🎓 छात्र: ${school.totalStudents}", fontSize = 12.sp)
                                Text(text = "👨‍🏫 शिक्षक: ${school.workingTeachers}", fontSize = 12.sp)
                                Text(text = "⚠️ पद रिक्त: ${school.vacantPosts}", fontSize = 12.sp, color = Color.Red)
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "📞 संपर्क: ${school.headmasterContact}", fontSize = 11.sp, color = Color.Gray)
                            Text(text = "✨ सुविधाएं: ${school.facilities}", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }
            } else {
                items(healthCentres) { hc ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = hc.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = RoyalNavy
                                )
                                if (hc.operates24x7) {
                                    Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(8.dp)) {
                                        Text(
                                            text = "24x7 एम्बुलेंस",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RoyalNavy,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "सेवाएं: ${hc.services}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "प्रभारी: ${hc.doctorIncharge}", fontSize = 12.sp)

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "📞 संपर्क: ${hc.phoneContact}", fontSize = 11.sp, color = SaffronOrange, fontWeight = FontWeight.Bold)
                                Text(text = "🚨 आपातकालीन: ${hc.emergencyHelpline}", fontSize = 11.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
