package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PromiseEntity
import com.example.data.model.VillageEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromiseTrackerScreen(
    promises: List<PromiseEntity>,
    villages: List<VillageEntity>,
    onPromiseClick: (String) -> Unit,
    onSubmitEvidenceClick: (promiseId: String, promiseTitle: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("सभी") }
    var selectedStatus by remember { mutableStateOf("सभी") }
    var selectedPanchayat by remember { mutableStateOf("सभी पंचायतें") }
    var selectedVillage by remember { mutableStateOf("सभी गांव") }

    val categories = listOf("सभी", "सड़क", "पानी", "बिजली", "शिक्षा", "स्वास्थ्य", "सिंचाई", "रोजगार", "खेल", "आवास", "अन्य")
    val statuses = listOf("सभी", "लंबित", "स्वीकृत", "प्रगति में", "पूर्ण", "स्थिति अज्ञात", "सत्यापन आवश्यक")

    val panchayats = remember(villages) {
        listOf("सभी पंचायतें") + villages.map { it.panchayat }.distinct().sorted()
    }

    val availableVillages = remember(selectedPanchayat, villages) {
        if (selectedPanchayat == "सभी पंचायतें") {
            listOf("सभी गांव") + villages.map { it.name }.distinct().sorted()
        } else {
            listOf("सभी गांव") + villages.filter { it.panchayat == selectedPanchayat }.map { it.name }.distinct().sorted()
        }
    }

    // Dynamic database calculation for Dashboard Counters
    val totalCount = promises.size
    val pendingCount = promises.count { it.status.contains("लंबित") }
    val approvedCount = promises.count { it.status.contains("स्वीकृत") }
    val inProgressCount = promises.count { it.status.contains("प्रगति में") }
    val completedCount = promises.count { it.status.contains("पूर्ण") }
    val unknownCount = promises.count { it.status.contains("स्थिति अज्ञात") || it.status.contains("अज्ञात") }
    val verificationNeededCount = promises.count { it.status.contains("सत्यापन आवश्यक") }

    val filteredPromises = remember(promises, searchQuery, selectedCategory, selectedStatus, selectedPanchayat, selectedVillage) {
        promises.filter { p ->
            val matchesSearch = searchQuery.isBlank() ||
                    p.title.contains(searchQuery, ignoreCase = true) ||
                    p.description.contains(searchQuery, ignoreCase = true) ||
                    p.village.contains(searchQuery, ignoreCase = true) ||
                    p.promiseId.contains(searchQuery, ignoreCase = true)

            val matchesCategory = selectedCategory == "सभी" || p.category == selectedCategory
            val matchesStatus = selectedStatus == "सभी" || p.status.contains(selectedStatus)
            val matchesPanchayat = selectedPanchayat == "सभी पंचायतें" || p.panchayat == selectedPanchayat
            val matchesVillage = selectedVillage == "सभी गांव" || p.village == selectedVillage

            matchesSearch && matchesCategory && matchesStatus && matchesPanchayat && matchesVillage
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        RoyalNavy,
                        RoyalNavy.copy(alpha = 0.95f),
                        Color(0xFF0D1B2A)
                    )
                )
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header Section ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = SaffronOrange,
                            shape = CircleShape,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(text = "📜", fontSize = 22.sp)
                            }
                        }
                        Column {
                            Text(
                                text = "झालरापाटन विधानसभा 198",
                                color = GoldenYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "जनता से किए गए वादे",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "वादों का रिकॉर्ड • जनता की निगरानी • जवाबदेही",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "सत्यापित",
                            tint = GoldenYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "सार्वजनिक अभिलेखों व प्रत्यक्ष धरातलीय सत्यापन पर आधारित",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // --- Promise Dashboard Summary Cards (Dynamic DB Calculation) ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "📊 वादा ट्रैकर डैशबोर्ड",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                ) {
                    item { DashboardStatCard("📜 कुल वादे", "$totalCount", GoldenYellow, Color.White.copy(alpha = 0.1f)) }
                    item { DashboardStatCard("⏳ लंबित", "$pendingCount", Color(0xFFFFB74D), Color(0xFFE65100).copy(alpha = 0.2f)) }
                    item { DashboardStatCard("🔵 स्वीकृत", "$approvedCount", Color(0xFF64B5F6), Color(0xFF1565C0).copy(alpha = 0.2f)) }
                    item { DashboardStatCard("🟠 प्रगति में", "$inProgressCount", Color(0xFFFF9800), Color(0xFFEF6C00).copy(alpha = 0.2f)) }
                    item { DashboardStatCard("✅ पूर्ण", "$completedCount", Color(0xFF81C784), Color(0xFF2E7D32).copy(alpha = 0.2f)) }
                    item { DashboardStatCard("⚪ स्थिति अज्ञात", "$unknownCount", Color(0xFFE0E0E0), Color.White.copy(alpha = 0.08f)) }
                    item { DashboardStatCard("🔴 सत्यापन आवश्यक", "$verificationNeededCount", Color(0xFFE57373), Color(0xFFC62828).copy(alpha = 0.2f)) }
                }
            }
        }

        // --- Hierarchy Village Filter (Assembly 198 -> Panchayat -> Village) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "स्थान",
                            tint = SaffronOrange,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "क्षेत्र के अनुसार खोजें (विधानसभा 198 → पंचायत → गांव)",
                            color = GoldenYellow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Panchayat Filter Selector
                        FilterDropdownChip(
                            label = if (selectedPanchayat == "सभी पंचायतें") "पंचायत चुनें" else selectedPanchayat,
                            items = panchayats,
                            onSelect = {
                                selectedPanchayat = it
                                selectedVillage = "सभी गांव"
                            },
                            modifier = Modifier.weight(1f)
                        )

                        // Village Filter Selector
                        FilterDropdownChip(
                            label = if (selectedVillage == "सभी गांव") "गांव चुनें" else selectedVillage,
                            items = availableVillages,
                            onSelect = { selectedVillage = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // --- Search Bar & Filters ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Search Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("वादा खोजें... (शीर्षक, गांव, वादा ID)", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = GoldenYellow) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "साफ़ करें", tint = Color.White)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldenYellow,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.White.copy(alpha = 0.08f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("promise_search_input")
                )

                // Category Filter Pills
                Text("श्रेणी अनुसार:", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        FilterChipPill(
                            label = cat,
                            isSelected = selectedCategory == cat,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }

                // Status Filter Pills
                Text("वर्तमान स्थिति:", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(statuses) { st ->
                        val isSel = selectedStatus == st
                        Surface(
                            color = if (isSel) GoldenYellow else Color.White.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable { selectedStatus = st }
                        ) {
                            Text(
                                text = st,
                                color = if (isSel) RoyalNavy else Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // --- Promises List Section ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "कुल वादे (${filteredPromises.size})",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                if (selectedCategory != "सभी" || selectedStatus != "सभी" || selectedVillage != "सभी गांव") {
                    TextButton(onClick = {
                        searchQuery = ""
                        selectedCategory = "सभी"
                        selectedStatus = "सभी"
                        selectedPanchayat = "सभी पंचायतें"
                        selectedVillage = "सभी गांव"
                    }) {
                        Text("फ़िल्टर हटाएं", color = SaffronOrange, fontSize = 12.sp)
                    }
                }
            }
        }

        if (filteredPromises.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "कोई वादा नहीं मिला",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "कृपया अपनी खोज शब्द या फ़िल्टर बदलकर पुनः प्रयास करें।",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            items(filteredPromises) { promise ->
                PromiseItemCard(
                    promise = promise,
                    onClick = { onPromiseClick(promise.id) },
                    onSubmitEvidence = { onSubmitEvidenceClick(promise.id, promise.title) }
                )
            }
        }
    }
}

@Composable
fun PromiseItemCard(
    promise: PromiseEntity,
    onClick: () -> Unit,
    onSubmitEvidence: () -> Unit
) {
    val statusColor = when {
        promise.status.contains("पूर्ण") -> Color(0xFF2E7D32)
        promise.status.contains("प्रगति में") -> Color(0xFFEF6C00)
        promise.status.contains("स्वीकृत") -> Color(0xFF1565C0)
        promise.status.contains("लंबित") -> Color(0xFFD84315)
        promise.status.contains("सत्यापन") -> Color(0xFFC62828)
        else -> Color(0xFF616161)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.07f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("promise_card_${promise.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Top Row: ID, Category & Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = GoldenYellow.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "ID: ${promise.promiseId}",
                        color = GoldenYellow,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = promise.category,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        color = statusColor,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = promise.status,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Title & Village
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = promise.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 22.sp
                )
                Text(
                    text = "📍 ${promise.village} • ${promise.panchayat}",
                    color = SaffronOrange,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Divider(color = Color.White.copy(alpha = 0.1f))

            // Promise Date & Source
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📅 वादा तिथि: ${promise.promiseDate}",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                    Text(
                        text = "🔎 स्रोत: ${promise.sourceType}",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 10.sp
                    )
                }

                Text(
                    text = "अंतिम सत्यापन: ${promise.lastVerifiedAt}",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp
                )
            }

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onSubmitEvidence() },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddAPhoto,
                        contentDescription = null,
                        tint = GoldenYellow,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("जानकारी/प्रमाण दें", color = GoldenYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text("पूरी जानकारी देखें →", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DashboardStatCard(
    label: String,
    count: String,
    accentColor: Color,
    bgColor: Color
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f)),
        modifier = Modifier.width(130.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(text = label, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = count, color = accentColor, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun FilterChipPill(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (isSelected) SaffronOrange else Color.White.copy(alpha = 0.1f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterDropdownChip(
    label: String,
    items: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        Surface(
            color = Color.White.copy(alpha = 0.1f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = GoldenYellow,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(RoyalNavy)
        ) {
            items.forEach { item ->
                DropdownMenuItem(
                    text = { Text(item, color = Color.White, fontSize = 12.sp) },
                    onClick = {
                        onSelect(item)
                        expanded = false
                    }
                )
            }
        }
    }
}
