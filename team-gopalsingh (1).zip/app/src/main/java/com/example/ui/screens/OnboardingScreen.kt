package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RoyalNavy
import com.example.ui.theme.SaffronOrange

@Composable
fun OnboardingScreen(onStartClick: () -> Unit) {
    var step by remember { mutableIntStateOf(1) }

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 40.dp)
            ) {
                Text(
                    text = "टीम गोपालसिंह ऐप में आपका स्वागत है",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = RoyalNavy,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "हरनावदा गजा • झालरापाटन 198",
                    fontSize = 12.sp,
                    color = SaffronOrange,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Step Content
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (step) {
                        1 -> {
                            Text(text = "🏛️", fontSize = 54.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "अपने गांव की जानकारी",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalNavy
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "हरनावदा गजा, ग्राम पंचायत, स्कूल, स्वास्थ्य केंद्र और झालरापाटन 198 क्षेत्र की पूरी प्रामाणिक जानकारी एक जगह देखें।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                        2 -> {
                            Text(text = "📝", fontSize = 54.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "जनसमस्या और विकास कार्य",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalNavy
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "पानी, सड़क, बिजली समस्या दर्ज करें। यूनिक आईडी (JHL-198-2026-XXX) से स्थिति ट्रैक करें व संबंधित विभाग में ऑनलाइन प्रेषित करें।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                        3 -> {
                            Text(text = "🤖", fontSize = 54.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "AI से सवाल पूछें",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalNavy
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "बोलकर या लिखकर सवाल पूछें। केवल verified रिकॉर्ड एवं सार्वजनिक डाटा से त्वरित उत्तर पाएं।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Bottom controls
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    repeat(3) { index ->
                        Box(
                            modifier = Modifier
                                .size(if (step == index + 1) 24.dp else 10.dp, 10.dp)
                                .background(
                                    if (step == index + 1) SaffronOrange else Color.LightGray,
                                    CircleShape
                                )
                        )
                    }
                }

                Button(
                    onClick = {
                        if (step < 3) {
                            step++
                        } else {
                            onStartClick()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_app_button")
                ) {
                    Text(
                        text = if (step < 3) "आगे बढ़ें →" else "शुरू करें",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
