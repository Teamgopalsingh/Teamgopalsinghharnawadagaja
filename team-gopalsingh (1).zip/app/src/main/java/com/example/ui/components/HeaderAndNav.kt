package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NavigationScreen
import com.example.ui.theme.*

@Composable
fun AppRoyalHeader(
    currentScreenTitle: String,
    onAdminClick: () -> Unit,
    onSearchClick: () -> Unit,
    onNotificationClick: () -> Unit
) {
    Surface(
        color = RoyalNavy,
        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(RoyalNavyDark, RoyalNavy, RoyalNavyLight)
                    )
                )
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Sun Temple Letterhead Subtle Motif Arch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .height(2.dp)
                        .weight(1f)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color.Transparent, RoyalGold, Color.Transparent)
                            )
                        )
                )
                Surface(
                    color = RoyalGoldDark,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RoyalGold),
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "🛕 सूर्य मंदिर प्रेरणा • झालरापाटन 198",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .height(2.dp)
                        .weight(1f)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color.Transparent, RoyalGold, Color.Transparent)
                            )
                        )
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Royal Emblem Badge
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(IvoryBg)
                            .border(2.dp, RoyalGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "👑",
                            fontSize = 22.sp
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "टीम गोपालसिंह",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                color = RoyalGold,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "हरनावदा गजा",
                                    color = RoyalNavyDark,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                            Text(
                                text = "• विधानसभा झालरापाटन 198",
                                color = RoyalGoldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onSearchClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, RoyalGold.copy(alpha = 0.4f), CircleShape)
                            .testTag("search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "खोजें",
                            tint = RoyalGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Surface(
                        color = RoyalGold,
                        shape = CircleShape,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White),
                        modifier = Modifier
                            .clickable { onAdminClick() }
                            .testTag("admin_button")
                    ) {
                        Text(
                            text = "एडमिन",
                            color = RoyalNavyDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    IconButton(
                        onClick = onNotificationClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, RoyalGold.copy(alpha = 0.4f), CircleShape)
                            .testTag("notification_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "सूचनाएं",
                            tint = RoyalGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppBottomBar(
    currentRoute: String,
    onNavigate: (NavigationScreen) -> Unit
) {
    var showMoreMenu by remember { mutableStateOf(false) }

    Surface(
        color = RoyalNavy,
        shadowElevation = 16.dp,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RoyalGold.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.Default.Home,
                label = "होम",
                isSelected = currentRoute == NavigationScreen.Home.route,
                onClick = { onNavigate(NavigationScreen.Home) }
            )
            BottomNavItem(
                icon = Icons.Default.Engineering,
                label = "विकास",
                isSelected = currentRoute == NavigationScreen.DevelopmentTracker.route,
                onClick = { onNavigate(NavigationScreen.DevelopmentTracker) }
            )
            BottomNavItem(
                icon = Icons.Default.RecordVoiceOver,
                label = "जनता की आवाज़",
                isSelected = currentRoute == NavigationScreen.Complaints.route,
                onClick = { onNavigate(NavigationScreen.Complaints) }
            )
            BottomNavItem(
                icon = Icons.Default.PhotoLibrary,
                label = "मीडिया",
                isSelected = currentRoute == NavigationScreen.SocialStudio.route,
                onClick = { onNavigate(NavigationScreen.SocialStudio) }
            )
            BottomNavItem(
                icon = Icons.Default.Menu,
                label = "अधिक",
                isSelected = showMoreMenu,
                onClick = { showMoreMenu = true }
            )
        }
    }

    if (showMoreMenu) {
        AlertDialog(
            onDismissRequest = { showMoreMenu = false },
            confirmButton = {
                TextButton(onClick = { showMoreMenu = false }) {
                    Text("बंद करें", color = RoyalGold, fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("👑", fontSize = 20.sp)
                    Text("मुख्य अनुभाग एवं सेवाएं", fontWeight = FontWeight.Black, color = RoyalNavy)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MoreMenuItem("🏛️ जनता से किए गए वादे", "वादों की सूची व सत्यापन स्थिति") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.PromiseTracker)
                    }
                    MoreMenuItem("📍 गांव की जानकारी (हरनावदा गजा)", "पंचायतों, सुविधाओं व वार्डों का विवरण") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.VillageDirectory)
                    }
                    MoreMenuItem("📢 महत्वपूर्ण सूचना", "क्षेत्रीय घोषणाएं व अपडेट्स") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.News)
                    }
                    MoreMenuItem("📋 सरकारी योजनाएं", "योजनाओं की सूची व आवेदन मार्गदर्शन") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.GovtSchemes)
                    }
                    MoreMenuItem("🏫 शिक्षा एवं स्वास्थ्य", "स्कूल, अस्पताल व आंगनवाड़ी") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.EducationHealth)
                    }
                    MoreMenuItem("👥 हमारी टीम", "टीम गोपालसिंह के प्रमुख कार्यकर्ता") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.Team)
                    }
                    MoreMenuItem("📞 संपर्क करें", "हेल्पलाइन 9166377972 व कार्यालय स्थान") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.ContactsDirectory)
                    }
                    MoreMenuItem("👤 मेरी प्रोफाइल", "उपयोगकर्ता जानकारी व सेटिंग्स") {
                        showMoreMenu = false
                        onNavigate(NavigationScreen.ProfileSettings)
                    }
                }
            },
            containerColor = IvoryBg,
            shape = RoundedCornerShape(20.dp)
        )
    }
}

@Composable
private fun MoreMenuItem(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderGold),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalNavy)
                Text(text = subtitle, fontSize = 11.sp, color = Color.Gray)
            }
            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = null,
                tint = RoyalGold,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) RoyalGold else Color.White.copy(alpha = 0.7f),
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
            color = if (isSelected) RoyalGold else Color.White.copy(alpha = 0.7f),
            maxLines = 1
        )
    }
}

